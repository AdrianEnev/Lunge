
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// build/server/server.js
import { createRequestHandler } from "@netlify/vite-plugin-react-router";
import { jsx, jsxs, Fragment } from "react/jsx-runtime";
import { PassThrough } from "node:stream";
import { createReadableStreamFromReadable } from "@react-router/node";
import { ServerRouter, useParams, useLoaderData, useActionData, useMatches, useRouteError, useNavigate, Meta, Links, ScrollRestoration, Scripts, Outlet, isRouteErrorResponse } from "react-router";
import { isbot } from "isbot";
import { renderToPipeableStream } from "react-dom/server";
import { createElement, useState, useEffect, createContext, useContext } from "react";
import i18n from "i18next";
import { initReactI18next, useTranslation } from "react-i18next";
import HttpBackend from "i18next-http-backend";
import { getAuth, onAuthStateChanged, sendPasswordResetEmail, signInWithEmailAndPassword, createUserWithEmailAndPassword } from "firebase/auth";
import { initializeApp } from "firebase/app";
import "firebase/analytics";
import { getFirestore, collection, doc, getDoc, getDocs, setDoc, updateDoc, serverTimestamp, deleteDoc } from "firebase/firestore";
import { faHome, faUser, faUsers, faDumbbell, faRunning, faUtensils, faChartLine, faCog, faPhone, faLanguage, faEdit, faArrowLeft } from "@fortawesome/free-solid-svg-icons";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { FixedSizeList } from "react-window";
import { DayPicker } from "react-day-picker";
import { enUS, bg as bg$1 } from "react-day-picker/locale";
var streamTimeout = 5e3;
function handleRequest(request, responseStatusCode, responseHeaders, routerContext, loadContext) {
  return new Promise((resolve, reject) => {
    let shellRendered = false;
    let userAgent = request.headers.get("user-agent");
    let readyOption = userAgent && isbot(userAgent) || routerContext.isSpaMode ? "onAllReady" : "onShellReady";
    const { pipe, abort } = renderToPipeableStream(
      /* @__PURE__ */ jsx(ServerRouter, { context: routerContext, url: request.url }),
      {
        [readyOption]() {
          shellRendered = true;
          const body = new PassThrough();
          const stream = createReadableStreamFromReadable(body);
          responseHeaders.set("Content-Type", "text/html");
          resolve(
            new Response(stream, {
              headers: responseHeaders,
              status: responseStatusCode
            })
          );
          pipe(body);
        },
        onShellError(error) {
          reject(error);
        },
        onError(error) {
          responseStatusCode = 500;
          if (shellRendered) {
            console.error(error);
          }
        }
      }
    );
    setTimeout(abort, streamTimeout + 1e3);
  });
}
var entryServer = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: handleRequest,
  streamTimeout
}, Symbol.toStringTag, { value: "Module" }));
function withComponentProps(Component) {
  return function Wrapped() {
    const props = {
      params: useParams(),
      loaderData: useLoaderData(),
      actionData: useActionData(),
      matches: useMatches()
    };
    return createElement(Component, props);
  };
}
function withErrorBoundaryProps(ErrorBoundary3) {
  return function Wrapped() {
    const props = {
      params: useParams(),
      loaderData: useLoaderData(),
      actionData: useActionData(),
      error: useRouteError()
    };
    return createElement(ErrorBoundary3, props);
  };
}
var stylesheet = "/assets/app-DVr2Ivlp.css";
var welcome$1 = "Welcome";
var home$1 = "Home";
var contact$1 = "Contact";
var email$1 = "Email";
var password$1 = "Password";
var done$1 = "Done";
var message$1 = "Message";
var account$1 = "Account";
var friends$1 = "Friends";
var food$1 = "Food Log";
var settings$1 = "Settings";
var statistics$1 = "Stats";
var workouts$1 = "Workouts";
var loading$1 = "Loading...";
var username$1 = "Username";
var edit$1 = "Edit";
var save$1 = "Save";
var cancel$1 = "Cancel";
var profile$1 = "Profile";
var user$1 = "User";
var logout$1 = "Log out";
var folders$1 = "Folders";
var title$1 = "Title";
var exercises$1 = "Exercises";
var set$1 = "Set";
var reps$1 = "Reps";
var weight$1 = "Weight";
var duration$1 = "Duration";
var grams$1 = "Grams";
var calories$1 = "Calories";
var protein$1 = "Protein";
var carbs$1 = "Carbs";
var fat$1 = "Fat";
var total$1 = "Total";
var kilograms$1 = "Kilograms";
var language$1 = "Language";
var seconds$1 = "Seconds";
var values$1 = "Values";
var en = {
  welcome: welcome$1,
  home: home$1,
  contact: contact$1,
  "sign-in": "Sign in",
  "sign-in-to-account": "Sign in to your account",
  email: email$1,
  password: password$1,
  "example-password": "SecurePassword123",
  "example-email": "example@gmail.com",
  done: done$1,
  "contact-us": "Contact us",
  message: message$1,
  account: account$1,
  friends: friends$1,
  "workout-splits": "Splits",
  "saved-workout-splits": "Completed",
  food: food$1,
  settings: settings$1,
  statistics: statistics$1,
  workouts: workouts$1,
  loading: loading$1,
  username: username$1,
  edit: edit$1,
  save: save$1,
  cancel: cancel$1,
  profile: profile$1,
  user: user$1,
  logout: logout$1,
  "friend-since": "Friend since",
  "workouts-completed": "Completed workouts",
  folders: folders$1,
  title: title$1,
  "created-on": "Created on",
  exercises: exercises$1,
  "retreiving-workout": "Retreiving workout...",
  set: set$1,
  reps: reps$1,
  weight: weight$1,
  duration: duration$1,
  "food-log": "Food Log",
  "food-2": "Food",
  grams: grams$1,
  calories: calories$1,
  protein: protein$1,
  carbs: carbs$1,
  fat: fat$1,
  total: total$1,
  "no-data-available": "No data available for this day!",
  "total-weight-lifted": "Weight lifted",
  kilograms: kilograms$1,
  "daily-goals": "Daily goals",
  language: language$1,
  seconds: seconds$1,
  values: values$1
};
var welcome = "\u0414\u043E\u0431\u0440\u0435 \u0434\u043E\u0448\u044A\u043B";
var home = "\u041D\u0430\u0447\u0430\u043B\u043E";
var contact = "\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u0438";
var email = "\u0418\u043C\u0435\u0439\u043B";
var password = "\u041F\u0430\u0440\u043E\u043B\u0430";
var done = "\u041D\u0430\u043F\u0440\u0435\u0434";
var message = "\u0421\u044A\u043E\u0431\u0449\u0435\u043D\u0438\u0435";
var account = "\u0410\u043A\u0430\u0443\u043D\u0442";
var friends = "\u041F\u0440\u0438\u044F\u0442\u0435\u043B\u0438";
var food = "\u0425\u0440\u0430\u043D\u0435\u043D\u0435";
var settings = "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438";
var statistics = "\u0421\u0442\u0430\u0442\u0438\u0441\u0442\u0438\u043A\u0438";
var workouts = "\u0422\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043A\u0438";
var loading = "\u0415\u0434\u043D\u0430 \u0441\u0435\u043A\u0443\u043D\u0434\u0430...";
var username = "\u041F\u043E\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043B\u0441\u043A\u043E \u0438\u043C\u0435";
var edit = "\u0421\u043C\u044F\u043D\u0430";
var save = "\u0417\u0430\u043F\u0430\u0437\u0438";
var cancel = "\u041E\u0442\u043A\u0430\u0437";
var profile = "\u041F\u0440\u043E\u0444\u0438\u043B";
var user = "\u041F\u043E\u0442\u0440\u0435\u0431\u0438\u0442\u0435\u043B";
var logout = "\u0418\u0437\u0445\u043E\u0434";
var folders = "\u041F\u0430\u043F\u043A\u0438";
var title = "\u0417\u0430\u0433\u043B\u0430\u0432\u0438\u0435";
var exercises = "\u0423\u043F\u0440\u0430\u0436\u043D\u0435\u043D\u0438\u044F";
var set = "\u0421\u0435\u0440\u0438\u044F";
var reps = "\u041F\u043E\u0432\u0442\u043E\u0440\u0435\u043D\u0438\u044F";
var weight = "\u0422\u0435\u0436\u0435\u0441\u0442";
var duration = "\u0412\u0440\u0435\u043C\u0435\u0442\u0440\u0430\u0435\u043D\u0435";
var grams = "\u0413\u0440\u0430\u043C\u0430\u0436";
var calories = "\u041A\u0430\u043B\u043E\u0440\u0438\u0438";
var protein = "\u041F\u0440\u043E\u0442\u0435\u0438\u043D";
var carbs = "\u0412\u044A\u0433\u043B\u0435\u0445\u0438\u0434\u0440\u0430\u0442\u0438";
var fat = "\u041C\u0430\u0437\u043D\u0438\u043D\u0438";
var total = "\u041E\u0431\u0449\u043E";
var kilograms = "\u041A\u0438\u043B\u043E\u0433\u0440\u0430\u043C\u0438";
var language = "\u0415\u0437\u0438\u043A";
var seconds = "\u0421\u0435\u043A\u0443\u043D\u0434\u0438";
var values = "\u0421\u0442\u043E\u0439\u043D\u043E\u0441\u0442\u0438";
var bg = {
  welcome,
  home,
  contact,
  "sign-in": "\u0412\u0445\u043E\u0434",
  "sign-in-to-account": "\u0412\u0445\u043E\u0434 \u0432 \u0430\u043A\u0430\u0443\u043D\u0442",
  email,
  password,
  "example-password": "\u0421\u0438\u043B\u043D\u0430\u041F\u0430\u0440\u043E\u043B\u0430123",
  "example-email": "\u041F\u0440\u0438\u043C\u0435\u0440\u0435\u043D\u0418\u043C\u0435\u0439\u043B@gmail.com",
  done,
  "contact-us": "\u0421\u0432\u044A\u0440\u0436\u0438 \u0441\u0435 \u0441 \u043D\u0430\u0441",
  message,
  account,
  friends,
  "workout-splits": "\u041F\u0440\u043E\u0433\u0440\u0430\u043C\u0438",
  "saved-workout-splits": "\u0417\u0430\u0432\u044A\u0440\u0448\u0435\u043D\u0438",
  food,
  settings,
  statistics,
  workouts,
  loading,
  username,
  edit,
  save,
  cancel,
  profile,
  user,
  logout,
  "friend-since": "\u041F\u0440\u0438\u044F\u0442\u0435\u043B \u043E\u0442",
  "workouts-completed": "\u0417\u0430\u0432\u044A\u0440\u0448\u0435\u043D\u0438 \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043A\u0438",
  folders,
  title,
  "created-on": "\u0414\u0430\u0442\u0430",
  exercises,
  "retreiving-workout": "\u0418\u0437\u0432\u043B\u0438\u0447\u0430\u043D\u0435 \u043D\u0430 \u0442\u0440\u0435\u043D\u0438\u0440\u043E\u0432\u043A\u0430...",
  set,
  reps,
  weight,
  duration,
  "food-log": "\u0425\u0440\u0430\u043D\u0438\u0442\u0435\u043B\u0435\u043D \u0420\u0435\u0436\u0438\u043C",
  "food-2": "\u0425\u0440\u0430\u043D\u0430",
  grams,
  calories,
  protein,
  carbs,
  fat,
  total,
  "no-data-available": "\u041D\u044F\u043C\u0430 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u0437\u0430 \u0442\u043E\u0437\u0438 \u0434\u0435\u043D!",
  "total-weight-lifted": "\u0412\u0434\u0438\u0433\u043D\u0430\u0442\u0438 \u043A\u0438\u043B\u043E\u0433\u0440\u0430\u043C\u0438",
  kilograms,
  "daily-goals": "\u0414\u043D\u0435\u0432\u043D\u0438 \u0446\u0435\u043B\u0438",
  language,
  seconds,
  values
};
i18n.use(HttpBackend).use(initReactI18next).init({
  resources: {
    en: { translation: en },
    bg: { translation: bg }
  },
  lng: "bg",
  fallbackLng: "en",
  interpolation: {
    escapeValue: false
  },
  debug: false
});
var firebaseConfig = {
  apiKey: "AIzaSyCU2y_-Elwo74ZyKy8CjQytK-BedpsX-o0",
  authDomain: "todo-mobile-app-3dcbc.firebaseapp.com",
  projectId: "todo-mobile-app-3dcbc",
  storageBucket: "todo-mobile-app-3dcbc.appspot.com",
  messagingSenderId: "418018705359",
  appId: "1:418018705359:web:45d6427d74cd12ec471cba",
  measurementId: "G-L8LBR0BEZ4"
};
var FIREBASE_APP = initializeApp(firebaseConfig);
var FIRESTORE_DB = getFirestore(FIREBASE_APP);
var FIREBASE_AUTH = getAuth(FIREBASE_APP);
var SidebarCategories = ({ icon, title: title2, route }) => {
  return /* @__PURE__ */ jsxs(
    "button",
    {
      className: "flex flex-row items-center gap-x-2 px-2 py-1 ml-[-5px] bg-gray-100 bg-opacity-0 rounded-md hover:bg-opacity-60",
      onClick: () => {
        route();
      },
      children: [
        /* @__PURE__ */ jsx(FontAwesomeIcon, { icon, className: "text-black w-5 h-5" }),
        /* @__PURE__ */ jsx("p", { className: `text-lg mt-[2px] text-gray-700`, children: title2 })
      ]
    }
  );
};
var SidebarAuthenticated = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(FIREBASE_AUTH.currentUser ? true : false);
  useState("Home");
  const [screenHeight, setScreenHeight] = useState(window.innerHeight);
  useEffect(() => {
    FIREBASE_AUTH.onAuthStateChanged((user2) => {
      if (user2) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
    });
  }, []);
  useEffect(() => {
    const handleResize = () => {
      setScreenHeight(getScreenHeight());
    };
    console.log(screenHeight);
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  const getScreenHeight = () => {
    return window.innerHeight;
  };
  const navigate = useNavigate();
  const { t } = useTranslation();
  return /* @__PURE__ */ jsx("div", { className: "w-full h-full font-rubik", children: /* @__PURE__ */ jsxs("div", { className: "w-full h-full mx-4 border-r border-gray-200 py-4 pr-12 pl-2", children: [
    /* @__PURE__ */ jsx("div", { className: "flex items-start gap-x-5", children: /* @__PURE__ */ jsx("button", { onClick: () => {
      navigate("/");
    }, children: /* @__PURE__ */ jsx("h1", { className: "text-2xl text-black font-semibold", children: "Lunge" }) }) }),
    /* @__PURE__ */ jsxs("div", { className: "mt-12 flex flex-col gap-y-1", children: [
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("home"), icon: faHome, route: () => navigate("/") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("account"), icon: faUser, route: () => navigate("/account") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("friends"), icon: faUsers, route: () => navigate("/friends") }),
      /* @__PURE__ */ jsx("p", { className: "text-gray-500 text-sm mt-5", children: t("workouts") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("workout-splits"), icon: faDumbbell, route: () => navigate("/workouts") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("saved-workout-splits"), icon: faRunning, route: () => navigate("/workouts/saved") }),
      /* @__PURE__ */ jsx("p", { className: "text-gray-500 text-sm mt-5", children: t("statistics") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("food"), icon: faUtensils, route: () => navigate("/food-log") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("statistics"), icon: faChartLine, route: () => navigate("/statistics") }),
      /* @__PURE__ */ jsx("p", { className: "text-gray-500 text-sm mt-5", children: t("settings") }),
      /* @__PURE__ */ jsx(SidebarCategories, { title: t("settings"), icon: faCog, route: () => navigate("/settings") }),
      /* @__PURE__ */ jsx("div", { className: `absolute bottom-4 ${screenHeight >= 700 ? "" : "hidden"}`, children: /* @__PURE__ */ jsx(SidebarCategories, { title: t("contact"), icon: faPhone, route: () => navigate("/contact") }) })
    ] })
  ] }) });
};
var HeaderUnauthenticated = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(FIREBASE_AUTH.currentUser ? true : false);
  const [language2, setLanguage] = useState(i18n.language);
  const { t } = useTranslation();
  useEffect(() => {
    FIREBASE_AUTH.onAuthStateChanged((user2) => {
      if (user2) {
        setIsAuthenticated(true);
      } else {
        setIsAuthenticated(false);
      }
    });
  }, []);
  const navigate = useNavigate();
  const changeLanguage = () => {
    const newLanguage = language2 === "en" ? "bg" : "en";
    i18n.changeLanguage(newLanguage);
    setLanguage(newLanguage);
  };
  return /* @__PURE__ */ jsx("div", { className: "w-auto h-16 m-2 mt-3 px-1 flex items-center font-rubik", children: /* @__PURE__ */ jsxs("div", { className: "flex w-full flex-row justify-between items-center mx-4", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-x-5", children: [
      /* @__PURE__ */ jsx("button", { onClick: () => {
        navigate("/");
      }, children: /* @__PURE__ */ jsx("h1", { className: "text-2xl text-black font-bold", children: "Lunge" }) }),
      /* @__PURE__ */ jsx("button", { onClick: () => {
        changeLanguage();
      }, children: /* @__PURE__ */ jsx(FontAwesomeIcon, { icon: faLanguage, className: "text-[#ff2056] text-lg w-10 h-10 mt-[6px]" }) })
    ] }),
    /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-x-5", children: [
      /* @__PURE__ */ jsx("button", { onClick: () => {
        navigate("/login");
      }, children: /* @__PURE__ */ jsxs("p", { className: "text-lg text-black font-medium hover:opacity-60 flex flex-row gap-x-2", children: [
        t("sign-in"),
        " >"
      ] }) }),
      /* @__PURE__ */ jsx(
        "button",
        {
          className: "w-24 p-2 rounded-full h-10 bg-rose-500 flex items-center justify-center hover:opacity-70",
          onClick: () => {
            navigate("/contact");
          },
          children: /* @__PURE__ */ jsx("p", { className: "text-base font-medium text-white", children: t("contact") })
        }
      )
    ] })
  ] }) });
};
var GlobalContext = createContext(void 0);
var GlobalProvider = ({ children }) => {
  const [loading2, setLoading] = useState(true);
  return /* @__PURE__ */ jsx(GlobalContext.Provider, { value: { loading: loading2, setLoading }, children });
};
var links = () => [{
  rel: "preconnect",
  href: "https://fonts.googleapis.com"
}, {
  rel: "preconnect",
  href: "https://fonts.gstatic.com",
  crossOrigin: "anonymous"
}, {
  rel: "stylesheet",
  href: "https://fonts.googleapis.com/css2?family=Inter:ital,opsz,wght@0,14..32,100..900;1,14..32,100..900&display=swap"
}, {
  rel: "stylesheet",
  href: stylesheet
}];
function Layout({
  children
}) {
  return /* @__PURE__ */ jsxs("html", {
    lang: "en",
    children: [/* @__PURE__ */ jsxs("head", {
      children: [/* @__PURE__ */ jsx("meta", {
        charSet: "utf-8"
      }), /* @__PURE__ */ jsx("meta", {
        name: "viewport",
        content: "width=device-width, initial-scale=1"
      }), /* @__PURE__ */ jsx(Meta, {}), /* @__PURE__ */ jsx(Links, {})]
    }), /* @__PURE__ */ jsxs("body", {
      children: [children, /* @__PURE__ */ jsx(ScrollRestoration, {}), /* @__PURE__ */ jsx(Scripts, {})]
    })]
  });
}
function AppContent() {
  const {
    loading: loading2,
    setLoading
  } = useContext(GlobalContext) || {
    loading: false,
    setLoading: () => {
    }
  };
  const [isAuthenticated, setIsAuthenticated] = useState(FIREBASE_AUTH.currentUser ? true : false);
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(FIREBASE_AUTH, (user2) => {
      if (user2) {
        console.log("user is logged in");
        setIsAuthenticated(true);
      } else {
        console.log("No user is logged in");
        setIsAuthenticated(false);
      }
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);
  useEffect(() => {
    const handleNavigationStart = () => {
      setLoading(true);
    };
    const handleNavigationEnd = () => {
      setLoading(false);
    };
    window.addEventListener("beforeunload", handleNavigationStart);
    window.addEventListener("load", handleNavigationEnd);
    return () => {
      window.removeEventListener("beforeunload", handleNavigationStart);
      window.removeEventListener("load", handleNavigationEnd);
    };
  }, []);
  if (loading2) {
    return /* @__PURE__ */ jsx("div", {
      children: /* @__PURE__ */ jsx("p", {
        className: "text-3xl font-medium text-center mt-12",
        children: "Loading..."
      })
    });
  }
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full",
    children: [!isAuthenticated && /* @__PURE__ */ jsx(HeaderUnauthenticated, {}), /* @__PURE__ */ jsxs("div", {
      className: "flex flex-row w-full h-full",
      children: [/* @__PURE__ */ jsx("div", {
        className: `${isAuthenticated ? "min-w-[14%]" : "w-0"} h-full`,
        children: isAuthenticated ? /* @__PURE__ */ jsx(SidebarAuthenticated, {}) : null
      }), /* @__PURE__ */ jsx("div", {
        className: `h-full ${isAuthenticated ? "w-[86%]" : "w-[95%]"} pl-8`,
        children: /* @__PURE__ */ jsxs("main", {
          className: "w-full h-full",
          children: [/* @__PURE__ */ jsx(Outlet, {}), " "]
        })
      })]
    })]
  });
}
var root = withComponentProps(function App() {
  return /* @__PURE__ */ jsx(GlobalProvider, {
    children: /* @__PURE__ */ jsx(AppContent, {})
  });
});
var ErrorBoundary = withErrorBoundaryProps(function ErrorBoundary2({
  error
}) {
  let message2 = "Oops!";
  let details = "An unexpected error occurred.";
  let stack;
  if (isRouteErrorResponse(error)) {
    message2 = error.status === 404 ? "404" : "Error";
    details = error.status === 404 ? "The requested page could not be found." : error.statusText || details;
  }
  return /* @__PURE__ */ jsxs("main", {
    className: "pt-16 p-4 container mx-auto",
    children: [/* @__PURE__ */ jsx("h1", {
      children: message2
    }), /* @__PURE__ */ jsx("p", {
      children: details
    }), stack]
  });
});
var route0 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  ErrorBoundary,
  Layout,
  default: root,
  links
}, Symbol.toStringTag, { value: "Module" }));
var HomeAuthenticated = ({ username: username2 }) => {
  const { t } = useTranslation();
  return /* @__PURE__ */ jsx("div", { className: "w-full h-full font-rubik p-5", children: /* @__PURE__ */ jsxs("div", { className: "flex flex-col", children: [
    /* @__PURE__ */ jsxs("div", { className: "flex flex-row gap-x-2 mt-5", children: [
      /* @__PURE__ */ jsxs("p", { className: "text-3xl text-black font-semibold", children: [
        t("welcome"),
        ","
      ] }),
      /* @__PURE__ */ jsx("p", { className: "text-3xl text-gray-700 font-medium", children: username2 })
    ] }),
    /* @__PURE__ */ jsx("p", { className: "text-3xl text-black mt-5 font-base", children: i18n.language == "en" ? "All account information will be displayed here." : "\u0412\u0441\u044F\u043A\u0430\u043A\u0432\u0430 \u0438\u043D\u0444\u043E\u0440\u043C\u0430\u0446\u0438\u044F \u0437\u0430 \u0430\u043A\u0430\u0443\u043D\u0442\u0430 \u0442\u0438 \u0449\u0435 \u0431\u044A\u0434\u0435 \u043F\u043E\u043A\u0430\u0437\u0430\u043D\u0430 \u0442\u0443\u043A." })
  ] }) });
};
var HomeUnauthenticated = ({ username: username2 }) => {
  const { t } = useTranslation();
  return /* @__PURE__ */ jsx("div", { className: "w-full h-full font-rubik flex justify-center pt-5", children: /* @__PURE__ */ jsx("div", { className: "flex flex-col", children: /* @__PURE__ */ jsxs("p", { className: "text-5xl text-black mt-5 font-base", children: [
    t("welcome"),
    "!"
  ] }) }) });
};
function meta({}) {
  return [{
    title: "Lunge"
  }, {
    name: "description",
    content: "Lunge: Fitness Tracker"
  }];
}
var Home = withComponentProps(function Home2() {
  const [username2, setUsername] = useState("User");
  const [isAuthenticated, setIsAuthenticated] = useState(FIREBASE_AUTH.currentUser ? true : false);
  useEffect(() => {
    setUsername(localStorage.getItem("username") || "User");
  }, []);
  return /* @__PURE__ */ jsx(Fragment, {
    children: isAuthenticated ? /* @__PURE__ */ jsx(HomeAuthenticated, {
      username: username2
    }) : /* @__PURE__ */ jsx(HomeUnauthenticated, {})
  });
});
var route1 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Home,
  meta
}, Symbol.toStringTag, { value: "Module" }));
var Contact = () => {
  const {
    t
  } = useTranslation();
  const [email2, setEmail] = useState("");
  const [message2, setMessage] = useState("");
  const [isAuthenticated, setIsAuthenticated] = useState(FIREBASE_AUTH.currentUser ? true : false);
  const sendMessage = async () => {
    console.log(email2);
    console.log(message2);
  };
  return /* @__PURE__ */ jsx("div", {
    className: "w-full h-full font-rubik",
    children: /* @__PURE__ */ jsx("div", {
      className: `${isAuthenticated ? "p-5" : "flex flex-col items-center justify-center mt-[5%]"}`,
      children: /* @__PURE__ */ jsxs("div", {
        className: `${isAuthenticated ? "w-[40%] h-98 bg-white rounded-xl border-gray-100" : "w-[40%] h-98 bg-white rounded-xl shadow-md border border-gray-100 px-14 py-12"}`,
        children: [/* @__PURE__ */ jsx("div", {
          className: "flex flex-col",
          children: /* @__PURE__ */ jsx("p", {
            className: "text-2xl text-gray-800 font-medium",
            children: t("contact-us")
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "flex w-full h-full flex-col mt-3",
          children: [/* @__PURE__ */ jsx("p", {
            className: "text-xl text-gray-600 my-2",
            children: t("email")
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            placeholder: t("example-email"),
            className: "border border-gray-300 p-2 rounded-md",
            onChange: (event) => setEmail(event.target.value)
          }), /* @__PURE__ */ jsx("p", {
            className: "text-xl text-gray-600 my-2",
            children: t("message")
          }), /* @__PURE__ */ jsx("textarea", {
            className: "border border-gray-300 p-2 rounded-md h-32",
            onChange: (event) => setMessage(event.target.value)
          }), /* @__PURE__ */ jsx("button", {
            className: "w-full h-12 bg-red-400 mt-3 rounded-xl active:opacity-60",
            onClick: () => sendMessage(),
            children: /* @__PURE__ */ jsx("p", {
              className: "text-xl font-medium text-white",
              children: i18n.language == "en" ? "Send" : t("done")
            })
          })]
        })]
      })
    })
  });
};
var Contact$1 = withComponentProps(Contact);
var route2 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Contact$1
}, Symbol.toStringTag, { value: "Module" }));
var apiToken = "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";
var checkUsernameNSFW = async (username2) => {
  console.log(apiToken);
  console.log("checking if username is nsfw");
  const isInList = await isUsernameInList(username2.toLowerCase());
  if (isInList) {
    console.log("username is in popular names list and is safe");
    return false;
  }
  const response = await fetch(
    "https://api-inference.huggingface.co/models/facebook/bart-large-mnli",
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiToken}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        inputs: username2,
        parameters: {
          candidate_labels: ["offensive", "non-offensive"]
        }
      })
    }
  );
  const data = await response.json();
  console.log(data);
  if (!data || !data.labels || data.labels.length === 0) {
    console.error("Unexpected API response format", data);
    return true;
  }
  console.log(data.labels[0]);
  if (data.labels[0] === "non-offensive") {
    console.log("username is not nsfw");
    return false;
  }
  console.log("username is nsfw");
  return true;
};
var isUsernameInList = (username2) => {
  const popularNames = /* @__PURE__ */ new Set([
    "liam",
    "olivia",
    "noah",
    "emma",
    "oliver",
    "ava",
    "elijah",
    "charlotte",
    "james",
    "sophia",
    "william",
    "amelia",
    "benjamin",
    "isabella",
    "lucas",
    "mia",
    "henry",
    "evelyn",
    "alexander",
    "harper",
    "mason",
    "luna",
    "michael",
    "camila",
    "ethan",
    "gianna",
    "daniel",
    "abigail",
    "jacob",
    "ella",
    "logan",
    "elizabeth",
    "jackson",
    "sofia",
    "sebastian",
    "avery",
    "jack",
    "scarlett",
    "aiden",
    "emily",
    "owen",
    "aria",
    "samuel",
    "penelope",
    "matthew",
    "chloe",
    "joseph",
    "layla",
    "levi",
    "mila",
    "mateo",
    "nora",
    "david",
    "hazel",
    "john",
    "madison",
    "wyatt",
    "ellie",
    "carter",
    "lily",
    "julian",
    "nova",
    "luke",
    "isla",
    "grayson",
    "grace",
    "isaac",
    "violet",
    "jayden",
    "aurora",
    "theodore",
    "riley",
    "gabriel",
    "zoey",
    "anthony",
    "willow",
    "dylan",
    "emilia",
    "leo",
    "stella",
    "lincoln",
    "zoe",
    "jaxon",
    "victoria",
    "asher",
    "hannah",
    "christopher",
    "addison",
    "josiah",
    "leah",
    "andrew",
    "lucy",
    "thomas",
    "eliana",
    "joshua",
    "ivy",
    "ezra",
    "everly",
    "adrian",
    "alex",
    "jordan"
  ]);
  return Promise.resolve(popularNames.has(username2));
};
var proceedChange = async (newUsername, oldUsername, setUsername) => {
  var _a;
  if (newUsername) {
    try {
      if (await checkUsernameNSFW(newUsername)) {
        setUsername(oldUsername);
        return;
      }
    } catch (error) {
      if (error && error.error && error.error.includes("Model facebook/bart-large-mnli is currently loading")) {
        setUsername(oldUsername);
        return;
      }
    }
    const trimmedUsername = newUsername.trim();
    console.log(trimmedUsername);
    if (newUsername.length <= 2) {
      setUsername(oldUsername);
      return;
    }
    const weirdCharPattern = /[^a-zA-Z0-9@#$£€%^&*()"'-/|.,?![]{}+=_~<>¥]/;
    if (weirdCharPattern.test(newUsername)) {
      setUsername(oldUsername);
      return;
    }
    let isUsernameTaken = false;
    const usersSnapshot = await getDocs(collection(FIRESTORE_DB, "users"));
    for (const doc2 of usersSnapshot.docs) {
      const userInfoCollectionRef = collection(doc2.ref, "user_info");
      const usernameDoc = await getDocs(userInfoCollectionRef);
      for (const doc3 of usernameDoc.docs) {
        if (doc3.id === "username") {
          if (doc3.data().username.trim() === trimmedUsername) {
            setUsername(oldUsername);
            isUsernameTaken = true;
            break;
          }
        }
      }
      if (isUsernameTaken)
        break;
    }
    if (isUsernameTaken)
      return;
    localStorage.setItem("username", trimmedUsername);
    try {
      const usersCollectionRef = collection(FIRESTORE_DB, "users");
      const userDocRef = doc(usersCollectionRef, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
      const userInfoCollectionRef = collection(userDocRef, "user_info");
      await setDoc(doc(userInfoCollectionRef, "username"), { username: trimmedUsername, date: /* @__PURE__ */ new Date() });
    } catch (err) {
      setUsername(oldUsername);
      alert("error");
    }
  }
};
var changeUsername = async (newUsername, oldUsername, setUsername) => {
  var _a, _b;
  const usersCollectionRef = collection(FIRESTORE_DB, "users");
  const userDocRef = doc(usersCollectionRef, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
  const userInfoCollectionRef = collection(userDocRef, "user_info");
  const usernameDocRef = doc(userInfoCollectionRef, "username");
  const usernameDoc = await getDoc(usernameDocRef);
  const usernameData = usernameDoc.data();
  const date = (_b = usernameData == null ? void 0 : usernameData.date) == null ? void 0 : _b.toDate();
  const currentDate = /* @__PURE__ */ new Date();
  const difference = currentDate.getTime() - ((date == null ? void 0 : date.getTime()) || 0);
  const daysDifference = difference / (1e3 * 3600 * 24);
  if (daysDifference < 7) {
    setUsername(oldUsername);
    alert("Please wait another " + Math.round(7 - daysDifference) + " days before changing your username again");
    return;
  }
  proceedChange(newUsername, oldUsername, setUsername);
};
var Account$1 = () => {
  var _a, _b;
  const navigate = useNavigate();
  const [loading2, setLoading] = useState(false);
  const [isAuthenticated, setIsAuthenticated] = useState(FIREBASE_AUTH.currentUser ? true : false);
  const [oldUsername, setOldUsername] = useState("");
  const [username2, setUsername] = useState("");
  const [editModeEnabled, setEditModeEnabled] = useState(false);
  const [passwordResetEmailSent, setPasswordResetEmailSent] = useState(false);
  const {
    t
  } = useTranslation();
  useEffect(() => {
    const username22 = localStorage.getItem("username");
    setUsername(username22 || "User");
    setOldUsername(username22 || "User");
  }, []);
  const changePassword = async () => {
    var _a2, _b2, _c, _d;
    if (passwordResetEmailSent) {
      return;
    }
    setPasswordResetEmailSent(true);
    const usersCollectionRef = collection(FIRESTORE_DB, "users");
    const userDocRef = doc(usersCollectionRef, (_a2 = FIREBASE_AUTH.currentUser) == null ? void 0 : _a2.uid);
    const userDocRefSnapshot = await getDoc(userDocRef);
    const lastSentEmail = new Date((_b2 = userDocRefSnapshot.data()) == null ? void 0 : _b2.resetPasswordEmailLastSent);
    const currentDate = /* @__PURE__ */ new Date();
    const difference = currentDate.getTime() - ((lastSentEmail == null ? void 0 : lastSentEmail.getTime()) || 0);
    const daysDifference = difference / (1e3 * 3600 * 24);
    if (daysDifference < 3) {
      setEditModeEnabled(false);
      setPasswordResetEmailSent(false);
      alert("Please wait another " + Math.round(3 - daysDifference) + " days before changing your password again");
      return;
    }
    const email2 = (_d = (_c = FIREBASE_AUTH.currentUser) == null ? void 0 : _c.email) == null ? void 0 : _d.toString();
    if (email2) {
      sendPasswordResetEmail(FIREBASE_AUTH, email2).then(async () => {
        const currentDateString = currentDate.toISOString();
        await updateDoc(userDocRef, {
          resetPasswordEmailLastSent: currentDateString
        });
        alert("email-sent-sucessfuly");
      }).catch((error) => {
        alert(error.message);
      });
    }
    setEditModeEnabled(false);
    setPasswordResetEmailSent(false);
  };
  const clearLocalStorageExcept = (exceptions) => {
    const keysToKeep = new Set(exceptions);
    Object.keys(localStorage).forEach((key) => {
      if (!keysToKeep.has(key)) {
        localStorage.removeItem(key);
      }
    });
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("profile")
    }), /* @__PURE__ */ jsxs("div", {
      className: "flex flex-row justify-between pr-4",
      children: [/* @__PURE__ */ jsx("p", {
        className: "text-lg font-medium mt-4",
        children: t("user")
      }), editModeEnabled && !loading2 ? /* @__PURE__ */ jsxs("div", {
        className: "flex flex-row gap-x-3",
        children: [/* @__PURE__ */ jsx("button", {
          className: "w-[70px] h-8 border border-gray-200 \n                            shadow-md rounded-lg flex flex-row items-center justify-center \n                            gap-x-2 active:opacity-60",
          onClick: () => {
            setEditModeEnabled(!editModeEnabled);
            setUsername(oldUsername);
          },
          children: /* @__PURE__ */ jsx("p", {
            children: t("cancel")
          })
        }), /* @__PURE__ */ jsx("button", {
          className: `w-[70px] h-8 bg-red-400 text-white 
                            shadow-md rounded-lg flex items-center justify-center 
                            gap-x-2 active:opacity-60 
                            ${username2 === localStorage.getItem("username") ? "opacity-60" : "opacity-100"}`,
          onClick: async () => {
            if (username2 !== oldUsername) {
              setLoading(true);
              await changeUsername(username2, oldUsername, setUsername);
              setEditModeEnabled(false);
              setLoading(false);
            }
          },
          children: /* @__PURE__ */ jsx("p", {
            children: t("save")
          })
        })]
      }) : !editModeEnabled && !loading2 ? /* @__PURE__ */ jsxs("button", {
        className: `${i18n.language == "en" ? "w-[70px]" : "w-[90px]"} h-8 border border-gray-200 
                            shadow-md rounded-lg flex flex-row items-center justify-center 
                            gap-x-2 active:opacity-60`,
        onClick: () => {
          setEditModeEnabled(!editModeEnabled);
        },
        children: [/* @__PURE__ */ jsx("p", {
          children: t("edit")
        }), /* @__PURE__ */ jsx(FontAwesomeIcon, {
          icon: faEdit,
          className: "text-black mt-[-1px]"
        })]
      }) : null]
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsxs("div", {
      className: "flex flex-row gap-x-16 mt-6",
      children: [/* @__PURE__ */ jsx("div", {
        children: !loading2 && /* @__PURE__ */ jsxs("div", {
          className: `flex flex-col ${editModeEnabled ? "gap-y-6" : "gap-y-6"}`,
          children: [/* @__PURE__ */ jsx("p", {
            children: t("email")
          }), /* @__PURE__ */ jsx("p", {
            children: t("username")
          }), /* @__PURE__ */ jsx("p", {
            children: t("password")
          })]
        })
      }), editModeEnabled && !loading2 ? /* @__PURE__ */ jsxs("div", {
        className: "flex flex-col gap-y-4",
        children: [/* @__PURE__ */ jsx("p", {
          children: (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.email
        }), /* @__PURE__ */ jsx("input", {
          type: "text",
          maxLength: 16,
          defaultValue: username2 || "",
          className: "border border-gray-300 rounded-md w-64 h-8 px-2",
          onChange: (event) => {
            setUsername(event.target.value);
          }
        }), /* @__PURE__ */ jsx("button", {
          className: "w-[160px] h-8 border border-gray-200 \n                            shadow-md rounded-lg flex flex-row items-center justify-center \n                            gap-x-2 active:opacity-60",
          onClick: () => {
            changePassword();
          },
          children: /* @__PURE__ */ jsx("p", {
            children: i18n.language == "en" ? "Change Password" : t("done")
          })
        })]
      }) : !editModeEnabled && !loading2 ? /* @__PURE__ */ jsxs("div", {
        className: "flex flex-col gap-y-6",
        children: [/* @__PURE__ */ jsx("p", {
          children: (_b = FIREBASE_AUTH.currentUser) == null ? void 0 : _b.email
        }), /* @__PURE__ */ jsx("p", {
          children: username2
        }), /* @__PURE__ */ jsx("p", {
          children: "*******"
        })]
      }) : /* @__PURE__ */ jsx("div", {
        children: /* @__PURE__ */ jsx("p", {
          className: "text-xl font-medium",
          children: t("loading")
        })
      })]
    }), /* @__PURE__ */ jsx("div", {
      className: "mt-12",
      children: /* @__PURE__ */ jsx("button", {
        onClick: () => {
          if (!isAuthenticated) {
            return;
          }
          FIREBASE_AUTH.signOut();
          clearLocalStorageExcept(["language"]);
          console.log("cleared storage");
          navigate("/");
        },
        children: /* @__PURE__ */ jsx("p", {
          className: "text-xl p-5 bg-red-400 rounded-xl text-white font-bold mt-3 shadow-md",
          children: t("logout")
        })
      })
    })]
  });
};
var Account$2 = withComponentProps(Account$1);
var route3 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Account$2
}, Symbol.toStringTag, { value: "Module" }));
var getUserLoginInfo = async (user2) => {
  const usersCollectionRef = collection(FIRESTORE_DB, "users");
  const userDocRef = doc(usersCollectionRef, user2.uid);
  const userInfoCollectionRef = collection(userDocRef, "user_info");
  console.log("Retreiving info...");
  getLanguage(userInfoCollectionRef);
  getWorkouts(userDocRef);
  getSavedWorkouts(userDocRef);
  getFoodDays(userDocRef);
  getFriends(userInfoCollectionRef);
  getStatistics(userInfoCollectionRef);
  getUsername(userInfoCollectionRef);
  getDailyGoals(userInfoCollectionRef);
  console.log("Everything was retreived successfuly");
};
var getDailyGoals = async (userInfoCollectionRef) => {
  const dailyGoalsDocRef = doc(userInfoCollectionRef, "nutrients");
  const dailyGoals = await getDoc(dailyGoalsDocRef);
  if (dailyGoals.exists()) {
    localStorage.setItem("dailyGoals", JSON.stringify(dailyGoals.data()));
  }
};
var getUsername = async (userInfoCollectionRef) => {
  const usernameDocRef = doc(userInfoCollectionRef, "username");
  const username2 = await getDoc(usernameDocRef);
  if (username2.exists()) {
    localStorage.setItem("username", username2.data().username);
  }
};
var getLanguage = async (userInfoCollectionRef) => {
  const languageDocRef = doc(userInfoCollectionRef, "language");
  const language2 = await getDoc(languageDocRef);
  if (language2.exists()) {
    localStorage.setItem("language", language2.data().language);
  }
};
var getStatistics = async (userInfoCollectionRef) => {
  const statisticsDocRef = doc(userInfoCollectionRef, "statistics");
  const statistics2 = await getDoc(statisticsDocRef);
  if (statistics2.exists()) {
    const statisticsData = statistics2.data();
    const statisticsArray = [
      { id: "finishedWorkouts", value: statisticsData.finishedWorkouts },
      { id: "weightLifted", value: statisticsData.weightLifted }
    ];
    localStorage.setItem("statistics", JSON.stringify(statisticsArray));
  }
};
var getWorkouts = async (userDocRef) => {
  const workoutsCollectionRef = collection(userDocRef, "workouts");
  const workoutsSnapshot = await getDocs(workoutsCollectionRef);
  const workoutsData = workoutsSnapshot.docs.map((doc2) => ({
    id: doc2.id,
    title: doc2.data().title || "Error!",
    created: doc2.data().created,
    colour: doc2.data().colour,
    folderId: doc2.data().folderId || null,
    numberOfExercises: doc2.data().numberOfExercises || 0
  })).sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());
  localStorage.setItem("workouts", JSON.stringify(workoutsData));
};
var getSavedWorkouts = async (userDocRef) => {
  const savedWorkoutsCollectionRef = collection(userDocRef, "saved_workouts");
  const savedWorkoutsSnapshot = await getDocs(savedWorkoutsCollectionRef);
  const savedWorkoutsData = savedWorkoutsSnapshot.docs.map((doc2) => ({
    id: doc2.id,
    title: doc2.data().title || "Error!",
    created: doc2.data().created,
    duration: doc2.data().duration
  })).sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());
  localStorage.setItem("saved_workouts", JSON.stringify(savedWorkoutsData));
};
var getFriends = async (userInfoCollectionRef) => {
  const friendsDocRef = doc(userInfoCollectionRef, "friends");
  const friendsListCollectionRef = collection(friendsDocRef, "list");
  const friendsSnapshot = await getDocs(friendsListCollectionRef);
  const friendsData = friendsSnapshot.docs.map((doc2) => {
    const data = doc2.data();
    return {
      id: doc2.id,
      username: data.username || "Error!"
    };
  });
  localStorage.setItem("friends", JSON.stringify(friendsData));
};
var getFoodDays = async (userDocRef) => {
  const foodDaysCollectionRef = collection(userDocRef, "food_days");
  const foodDaysSnapshot = await getDocs(foodDaysCollectionRef);
  const foodDaysData = foodDaysSnapshot.docs.map((doc2) => {
    const data = doc2.data();
    const title2 = data.title || "Error!";
    const created = new Date(title2);
    return {
      id: doc2.id,
      title: title2,
      calories: data.calories || "-",
      protein: data.protein || "-",
      carbs: data.carbs || "-",
      fat: data.fat || "-",
      created
    };
  }).sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());
  localStorage.setItem("food_days", JSON.stringify(foodDaysData));
};
var Account = () => {
  const navigate = useNavigate();
  const {
    t
  } = useTranslation();
  const [password2, setPassword] = useState("");
  const [email2, setEmail] = useState("");
  useState(FIREBASE_AUTH.currentUser ? true : false);
  const {
    setLoading
  } = useContext(GlobalContext) || {
    setLoading: () => {
      console.log("error");
    }
  };
  const handleFirebaseLogin = (email22, password22) => {
    var _a;
    const currentUser = (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid;
    if (currentUser) {
      console.log("User already logged in");
      return;
    }
    signInWithEmailAndPassword(FIREBASE_AUTH, email22, password22).then(async (userCredential) => {
      const user2 = userCredential.user;
      setLoading(true);
      await getUserLoginInfo(user2);
      setLoading(false);
      navigate("/");
    }).catch((error) => {
      error.code;
      error.message;
    });
  };
  const handleLogin = () => {
    if (email2 === "" || password2 === "") {
      alert("Please fill in all fields");
      return;
    }
    handleFirebaseLogin(email2, password2);
  };
  return /* @__PURE__ */ jsx("div", {
    className: "w-full h-full font-rubik",
    children: /* @__PURE__ */ jsx("div", {
      className: "flex flex-col items-center justify-center mt-[5%]",
      children: /* @__PURE__ */ jsxs("div", {
        className: "w-[40%] h-96 bg-white rounded-xl shadow-md border border-gray-100 px-14 py-12",
        children: [/* @__PURE__ */ jsx("div", {
          className: "flex flex-col",
          children: /* @__PURE__ */ jsx("p", {
            className: "text-2xl text-gray-800 font-medium",
            children: t("sign-in-to-account")
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "flex w-full h-full flex-col mt-3",
          children: [/* @__PURE__ */ jsx("p", {
            className: "text-xl text-gray-600 my-2",
            children: t("email")
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            onChange: (event) => setEmail(event.target.value),
            placeholder: t("example-email"),
            className: "border border-gray-300 p-2 rounded-md"
          }), /* @__PURE__ */ jsx("p", {
            className: "text-xl text-gray-600 my-2",
            children: t("password")
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            onChange: (event) => setPassword(event.target.value),
            placeholder: t("example-password"),
            className: "border border-gray-300 p-2 rounded-md"
          }), /* @__PURE__ */ jsx("button", {
            className: "w-full h-12 bg-red-400 mt-3 rounded-xl active:opacity-60",
            onClick: handleLogin,
            children: /* @__PURE__ */ jsx("p", {
              className: "text-xl font-medium text-white",
              children: i18n.language == "en" ? t("sign-in") : t("done")
            })
          })]
        })]
      })
    })
  });
};
var AccountLogin = withComponentProps(Account);
var route4 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AccountLogin
}, Symbol.toStringTag, { value: "Module" }));
var AccountRegister = () => {
  useState(FIREBASE_AUTH.currentUser ? true : false);
  const navigate = useNavigate();
  const [email2, setEmail] = useState("");
  const [username2, setUsername] = useState("");
  const [password2, setPassword] = useState("");
  const [passwordConfirm, setPasswordConfirm] = useState("");
  const [registerButtonDisabled, setRegisterButtonDisabled] = useState(false);
  const [passwordCharacters, setPasswordCharacters] = useState(65);
  const [confirmPasswordCharacters, setPasswordConfirmCharacters] = useState(65);
  const [passwordStrength, setPasswordStrength] = useState("");
  const [passwordConfirmStrenght, setPasswordConfirmStrenght] = useState("");
  const signUp = async () => {
    const trimmedUsername = username2.trim();
    const trimmedEmail = email2.trim();
    if (trimmedEmail.length == 0 || password2.length == 0 || passwordConfirm.length == 0 || trimmedUsername.length == 0) {
      setRegisterButtonDisabled(false);
      return;
    }
    const weirdCharPattern = /[^a-zA-Z0-9@#$£€%^&*()"'-/|.,?![]{}+=_~<>¥]/;
    if (weirdCharPattern.test(password2)) {
      alert("password-no-emojis");
      return;
    }
    if (password2 !== passwordConfirm) {
      alert("passwords-not-match");
      return;
    }
    if (trimmedUsername.length <= 2) {
      alert("username-at-least-three-symbols");
      return;
    }
    if (password2.length <= 8) {
      alert("password-at-least-eight-symbols");
      return;
    }
    if (password2 === trimmedUsername) {
      alert("password-not-same-as-username");
      return;
    }
    if (await checkUsernameNSFW(trimmedUsername)) {
      alert("nsfw-username");
      return;
    }
    if (await isUsernameTaken(trimmedUsername)) {
      alert("username-taken");
      return;
    }
    try {
      const after = await createUserWithEmailAndPassword(FIREBASE_AUTH, trimmedEmail, password2);
      const usersCollectionRef = collection(FIRESTORE_DB, "users");
      const userDocRef = doc(usersCollectionRef, after.user.uid);
      await setDoc(userDocRef, {
        lungeCoins: 1,
        lastGeneratedWorkout: null
      }, {
        merge: false
      });
      const userInfoCollectionRef = collection(userDocRef, "user_info");
      await setDoc(doc(userInfoCollectionRef, "username"), {
        username: trimmedUsername
      });
      navigate("/");
    } catch (err) {
      console.log("error", err);
    }
  };
  const isUsernameTaken = async (trimmedUsername) => {
    const usersSnapshot = await getDocs(collection(FIRESTORE_DB, "users"));
    for (const doc2 of usersSnapshot.docs) {
      const userInfoCollectionRef = collection(doc2.ref, "user_info");
      const usernameDoc = await getDocs(userInfoCollectionRef);
      for (const user2 of usernameDoc.docs) {
        if (user2.id === "username" && user2.data().username.trim() === trimmedUsername) {
          return true;
        }
      }
    }
    return false;
  };
  const checkPasswordStrength = (password22) => {
    if (password22.length <= 8) {
      return "weak";
    }
    if (password22.length <= 12) {
      let hasNumber = /\d/.test(password22);
      let hasSpecialChar = /[^A-Za-z0-9]/.test(password22);
      if (hasNumber && hasSpecialChar) {
        return "strong";
      } else if (hasNumber || hasSpecialChar) {
        return "decent";
      } else {
        return "weak";
      }
    }
    if (password22.length > 12) {
      let hasNumber = /\d/.test(password22);
      let hasSpecialChar = /[^A-Za-z0-9]/.test(password22);
      if (hasNumber && hasSpecialChar) {
        return "very strong";
      } else if (hasNumber || hasSpecialChar) {
        return "good";
      } else {
        return "decent";
      }
    }
    return "weak";
  };
  useEffect(() => {
    setPasswordCharacters(65 - password2.length);
    setPasswordConfirmCharacters(65 - passwordConfirm.length);
    const strength = checkPasswordStrength(password2);
    setPasswordStrength(strength);
    const confirmStrenght = checkPasswordStrength(passwordConfirm);
    setPasswordConfirmStrenght(confirmStrenght);
  }, [password2, passwordConfirm]);
  const handleRegister = () => {
    if (email2 === "" || password2 === "") {
      alert("Please fill in all fields");
      return;
    }
    signUp();
  };
  return /* @__PURE__ */ jsx("div", {
    className: "w-full h-full",
    children: /* @__PURE__ */ jsx("div", {
      className: "flex flex-col items-center justify-center mt-[7%]",
      children: /* @__PURE__ */ jsxs("div", {
        className: "w-[37%] h-[500px] bg-white rounded-xl shadow-md",
        children: [/* @__PURE__ */ jsx("div", {
          className: "flex flex-col items-center justify-center mt-3",
          children: /* @__PURE__ */ jsx("p", {
            className: "text-2xl text-black font-bold",
            children: "Account"
          })
        }), /* @__PURE__ */ jsxs("div", {
          className: "flex w-full h-full flex-col items-center mt-5",
          children: [/* @__PURE__ */ jsx("p", {
            className: "text-xl font-medium text-gray-600 mb-2",
            children: "Register"
          }), /* @__PURE__ */ jsx("p", {
            className: "text-xl font-medium text-gray-600 mt-2",
            children: "Email"
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            onChange: (event) => setEmail(event.target.value),
            placeholder: "Type something...",
            className: "border border-gray-300 p-2"
          }), /* @__PURE__ */ jsx("p", {
            className: "text-xl font-medium text-gray-600 mt-2",
            children: "username"
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            onChange: (event) => setUsername(event.target.value),
            placeholder: "Type something...",
            className: "border border-gray-300 p-2"
          }), /* @__PURE__ */ jsx("p", {
            className: "text-xl font-medium text-gray-600 mt-2",
            children: "password"
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            onChange: (event) => setPassword(event.target.value),
            placeholder: "Type something...",
            className: "border border-gray-300 p-2"
          }), /* @__PURE__ */ jsx("p", {
            className: "text-xl font-medium text-gray-600 mt-2",
            children: "confirm password"
          }), /* @__PURE__ */ jsx("input", {
            type: "text",
            onChange: (event) => setPasswordConfirm(event.target.value),
            placeholder: "Type something...",
            className: "border border-gray-300 p-2"
          }), /* @__PURE__ */ jsx("button", {
            className: "w-24 h-12 bg-red-400 mt-3 active:opacity-60",
            onClick: handleRegister,
            children: /* @__PURE__ */ jsx("p", {
              className: "text-xl font-medium text-white mt-2",
              children: "Register"
            })
          })]
        })]
      })
    })
  });
};
var AccountRegister$1 = withComponentProps(AccountRegister);
var route5 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: AccountRegister$1
}, Symbol.toStringTag, { value: "Module" }));
var changeDailyGoal = async (nutrient, dailyGoals, newValue) => {
  var _a;
  const dailyGoal = dailyGoals[0];
  if (dailyGoal.hasOwnProperty(nutrient)) {
    dailyGoal[nutrient] = Number(newValue);
    localStorage.setItem("dailyGoals", JSON.stringify(dailyGoal));
    try {
      const usersCollectionRef = collection(FIRESTORE_DB, "users");
      const userDocRef = doc(usersCollectionRef, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
      const userInfoCollectionRef = collection(userDocRef, "user_info");
      const nutrientsDocRef = doc(userInfoCollectionRef, "nutrients");
      const { id, ...dailyGoalWithoutId } = dailyGoal;
      const dailyGoalWithNumbers = Object.fromEntries(
        Object.entries(dailyGoalWithoutId).map(([key, value]) => [key, Number(value)])
      );
      await setDoc(nutrientsDocRef, dailyGoalWithNumbers, { merge: true });
    } catch (e) {
      console.log(e);
    }
  } else {
    throw new Error("Invalid nutrient");
  }
};
var DailyGoalsElement = ({ dailyGoal, index, selectedNutrient, setSelectedNutrient, dailyGoals }) => {
  return /* @__PURE__ */ jsx(
    "div",
    {
      className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
            flex flex-row items-center
           `,
      children: ["calories", "protein", "carbs", "fat"].map((nutrient) => /* @__PURE__ */ jsx(
        "button",
        {
          className: `text-base w-1/4 hover:opacity-50 
                        ${selectedNutrient === nutrient ? "text-red-400" : ""}
                    `,
          onClick: () => setSelectedNutrient(nutrient),
          children: selectedNutrient === nutrient ? /* @__PURE__ */ jsx(
            "input",
            {
              type: "text",
              defaultValue: dailyGoal[nutrient],
              className: "w-full text-center border-none outline-none",
              onBlur: (e) => {
                setSelectedNutrient("");
                changeDailyGoal(nutrient, dailyGoals, e.target.value);
              },
              onKeyDown: (e) => {
                if (e.key === "Enter") {
                  setSelectedNutrient("");
                  changeDailyGoal(nutrient, dailyGoals, e.currentTarget.value);
                }
              },
              maxLength: selectedNutrient === "calories" ? 4 : 3
            }
          ) : /* @__PURE__ */ jsx("p", { children: dailyGoal[nutrient] })
        },
        nutrient
      ))
    }
  );
};
var Settings = () => {
  const [selectedNutrient, setSelectedNutrient] = useState("");
  const [dailyGoals, setDailyGoals] = useState([]);
  const [loading2, setLoading] = useState(false);
  const [language2, setLanguage] = useState(i18n.language);
  const {
    t
  } = useTranslation();
  const dailyGoalsLS = localStorage.getItem("dailyGoals");
  useEffect(() => {
    if (dailyGoalsLS) {
      const dailyGoalsObject = JSON.parse(dailyGoalsLS);
      const convertToGoalNutrients = (obj) => {
        return [{
          ...obj,
          id: crypto.randomUUID()
        }];
      };
      const convertedDailyGoals = convertToGoalNutrients(dailyGoalsObject);
      setDailyGoals(convertedDailyGoals);
    }
  }, [dailyGoalsLS]);
  const changeLanguage = () => {
    const newLanguage = language2 === "en" ? "bg" : "en";
    i18n.changeLanguage(newLanguage);
    setLanguage(newLanguage);
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("settings")
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsx("div", {
      className: "h-52",
      children: loading2 ? /* @__PURE__ */ jsx("div", {
        className: "mt-2",
        children: /* @__PURE__ */ jsx("p", {
          className: "text-xl text-red-500",
          children: t("loading")
        })
      }) : dailyGoals ? /* @__PURE__ */ jsx("div", {
        className: "flex flex-row flex-wrap gap-x-2 gap-y-12 w-full",
        children: /* @__PURE__ */ jsxs("div", {
          className: "w-full",
          children: [/* @__PURE__ */ jsx("p", {
            className: "text-xl text-gray-700 mt-4 mb-2 font-medium",
            children: t("daily-goals")
          }), /* @__PURE__ */ jsxs("div", {
            className: "w-full h-full border border-gray-200 rounded-md mb-4",
            children: [/* @__PURE__ */ jsxs("div", {
              className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
              children: [/* @__PURE__ */ jsx("p", {
                className: "w-1/4 text-center text-lg mr-[-20px]",
                children: t("calories")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/4 text-center text-lg mr-[-20px]",
                children: t("protein")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/4 text-center text-lg ",
                children: t("carbs")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/4 text-center text-lg ml-[-20px]",
                children: t("fat")
              })]
            }), dailyGoals.map((dailyGoal, index) => /* @__PURE__ */ jsx(DailyGoalsElement, {
              dailyGoal,
              index,
              selectedNutrient,
              setSelectedNutrient,
              dailyGoals
            }, dailyGoal.id))]
          })]
        })
      }) : /* @__PURE__ */ jsx("div", {
        children: /* @__PURE__ */ jsx("p", {
          children: t("no-data-available")
        })
      })
    }), /* @__PURE__ */ jsx("button", {
      onClick: () => {
        changeLanguage();
      },
      className: "absolute bottom-0 right-4",
      children: /* @__PURE__ */ jsx(FontAwesomeIcon, {
        icon: faLanguage,
        className: "text-[#ff2056] text-lg w-10 h-10 mt-[6px]"
      })
    })]
  });
};
var Settings$1 = withComponentProps(Settings);
var route6 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Settings$1
}, Symbol.toStringTag, { value: "Module" }));
var timestampToDate = (value) => {
  let date;
  if (typeof value === "string") {
    date = new Date(value);
  } else {
    date = new Date(value.seconds * 1e3 + value.nanoseconds / 1e6);
  }
  return date.toLocaleString();
};
var Workouts = () => {
  const {
    t
  } = useTranslation();
  const WorkoutElement = ({
    workout,
    navigate: navigate2
  }) => {
    const workoutDate = timestampToDate(workout.created).split(" ")[0].slice(0, -1);
    return /* @__PURE__ */ jsxs("button", {
      className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
                flex flex-row items-center
                hover:opacity-50 hover:bg-gray-100`,
      onClick: () => {
        if (workout.title == "Rest~+!_@)#($*&^@&$^*@^$&@*$&#@&#@(&#$@*&($") {
          return;
        }
        navigate2(`workout/${workout.id}`);
      },
      children: [/* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: workout.title !== "Rest~+!_@)#($*&^@&$^*@^$&@*$&#@&#@(&#$@*&($" ? workout.title : "Rest Day"
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: workoutDate
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: workout.numberOfExercises
      })]
    });
  };
  const FolderElement = (folder) => {
    const workoutCount = folder.workouts.length;
    return /* @__PURE__ */ jsxs("button", {
      className: "w-full h-10 text-gray-600 border-y border-gray-100 px-3 \n                flex items-center\n                hover:opacity-50",
      onClick: () => {
        setSelectedFolderWorkouts(folder.workouts);
      },
      children: [/* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: folder.title
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: "-"
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: workoutCount
      })]
    });
  };
  const [selectedFolderWorkouts, setSelectedFolderWorkouts] = useState([]);
  const [workouts2, setWorkouts] = useState([]);
  const [folders2, setFolders] = useState([]);
  const navigate = useNavigate();
  useEffect(() => {
    const workoutsLS = localStorage.getItem("workouts");
    const folderMap = {};
    const workouts22 = [];
    if (workoutsLS) {
      const workoutsData = JSON.parse(workoutsLS);
      workoutsData.forEach((workout) => {
        if (workout.folderId) {
          if (!folderMap[workout.folderId]) {
            folderMap[workout.folderId] = [];
          }
          folderMap[workout.folderId].push(workout);
        } else {
          workouts22.push(workout);
        }
      });
    }
    const folders22 = Object.keys(folderMap).map((folderId) => {
      const middleDigit = folderId.replace("folder_", "")[Math.floor((folderId.replace("folder_", "").length - 1) / 2)];
      return {
        id: folderId,
        title: `Folder ${middleDigit}`,
        folderId,
        workouts: folderMap[folderId],
        exercises: [],
        colour: "",
        numberOfExercises: 0,
        created: serverTimestamp()
      };
    });
    setWorkouts(workouts22);
    setFolders(folders22);
  }, []);
  const workoutItems = [...workouts2];
  const folderItems = [...folders2];
  const selectedFolderWorkoutItems = [...selectedFolderWorkouts];
  const WorkoutsRenderer = ({
    index,
    style
  }) => {
    if (workoutItems.length === 0) {
      return /* @__PURE__ */ jsx("div", {
        style,
        children: /* @__PURE__ */ jsx("p", {
          className: "text-center text-gray-500",
          children: t("no-workouts")
        })
      });
    }
    const sortedWorkoutItems = workoutItems.sort((a, b) => {
      if (a.created && b.created) {
        const dateA = new Date(a.created.seconds * 1e3);
        const dateB = new Date(b.created.seconds * 1e3);
        return dateB.getTime() - dateA.getTime();
      }
    });
    const item = sortedWorkoutItems[index] || workoutItems[index];
    return /* @__PURE__ */ jsx("div", {
      style,
      children: /* @__PURE__ */ jsx(WorkoutElement, {
        ...item,
        workout: item,
        navigate
      }, item.id)
    });
  };
  const FoldersRenderer = ({
    index,
    style
  }) => {
    const item = folderItems[index];
    return /* @__PURE__ */ jsx("div", {
      style,
      children: /* @__PURE__ */ jsx(FolderElement, {
        ...item
      }, item.id)
    });
  };
  const SelectedFolderWorkoutsRenderer = ({
    index,
    style
  }) => {
    const sortedWorkoutItems = selectedFolderWorkoutItems.sort((a, b) => {
      if (a.created && b.created) {
        const dateA = new Date(a.created.seconds * 1e3);
        const dateB = new Date(b.created.seconds * 1e3);
        return dateB.getTime() - dateA.getTime();
      }
    });
    const item = sortedWorkoutItems[index] || selectedFolderWorkoutItems[index];
    return /* @__PURE__ */ jsx("div", {
      style,
      children: /* @__PURE__ */ jsx(WorkoutElement, {
        ...item,
        workout: item,
        navigate
      }, item.id)
    });
  };
  const [screenHeight, setScreenHeight] = useState(window.innerHeight);
  const [screenWidth, setScreenWidth] = useState(window.innerWidth);
  useEffect(() => {
    const handleResize = () => {
      setScreenHeight(getScreenHeight());
      setScreenWidth(getScreenWidth());
    };
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  const getScreenHeight = () => {
    return window.innerHeight;
  };
  const getScreenWidth = () => {
    return window.innerWidth;
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5 overflow-y-auto",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("workout-splits")
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsxs("div", {
      className: "flex flex-row justify-between mt-2 mb-1 px-2",
      children: [selectedFolderWorkoutItems.length > 0 && /* @__PURE__ */ jsxs("div", {
        className: "flex flex-row",
        children: [selectedFolderWorkouts.length !== 0 && /* @__PURE__ */ jsx("button", {
          className: "pt-2 px-2",
          onClick: () => {
            setSelectedFolderWorkouts([]);
          },
          children: /* @__PURE__ */ jsx(FontAwesomeIcon, {
            icon: faArrowLeft,
            className: "w-5 h-5 font-medium text-gray-700"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "text-xl font-medium text-yellow-400 w-[49%] mt-[6px]",
          children: t("folders")
        })]
      }), /* @__PURE__ */ jsx("p", {
        className: `text-xl font-medium text-red-400 w-[49%] mt-[6px] ${screenWidth > 1050 ? "" : "hidden"}`,
        children: t("workouts")
      })]
    }), /* @__PURE__ */ jsxs("div", {
      className: `flex ${screenWidth > 1050 ? "flex-row" : "flex-col"} w-full h-[60%] gap-x-2`,
      children: [selectedFolderWorkoutItems.length > 0 && /* @__PURE__ */ jsxs("div", {
        className: `
                            w-[49%] h-full border border-gray-200 rounded-md
                        `,
        children: [/* @__PURE__ */ jsxs("div", {
          className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
          children: [/* @__PURE__ */ jsx("p", {
            className: "w-1/3 text-center text-lg mr-[-24px]",
            children: t("title")
          }), /* @__PURE__ */ jsx("p", {
            className: "w-1/3 text-center text-lg",
            children: t("created-on")
          }), /* @__PURE__ */ jsx("p", {
            className: "w-1/3 text-center text-lg ml-[-24px]",
            children: t("workouts")
          })]
        }), /* @__PURE__ */ jsx(FixedSizeList, {
          height: 410,
          width: "100%",
          itemCount: selectedFolderWorkouts.length === 0 ? folderItems.length : selectedFolderWorkoutItems.length,
          itemSize: 40,
          layout: "vertical",
          children: selectedFolderWorkouts.length === 0 ? FoldersRenderer : SelectedFolderWorkoutsRenderer
        })]
      }), /* @__PURE__ */ jsx("p", {
        className: `text-xl font-medium text-red-400 w-[49%] mt-[6px] 
                    ${screenWidth > 1050 ? "hidden" : ""}`,
        children: t("workouts")
      }), /* @__PURE__ */ jsxs("div", {
        className: `${selectedFolderWorkoutItems.length > 0 ? "w-[49%]" : "w-full"} h-full border border-gray-200 rounded-md`,
        children: [/* @__PURE__ */ jsxs("div", {
          className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
          children: [/* @__PURE__ */ jsx("p", {
            className: "w-1/3 text-center text-lg mr-[-24px]",
            children: t("title")
          }), /* @__PURE__ */ jsx("p", {
            className: "w-1/3 text-center text-lg",
            children: t("created-on")
          }), /* @__PURE__ */ jsx("p", {
            className: "w-1/3 text-center text-lg ml-[-24px]",
            children: t("exercises")
          })]
        }), /* @__PURE__ */ jsx(FixedSizeList, {
          height: 410,
          width: "100%",
          itemCount: workoutItems.length,
          itemSize: 40,
          layout: "vertical",
          children: WorkoutsRenderer
        })]
      })]
    })]
  });
};
var Workouts$1 = withComponentProps(Workouts);
var route7 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Workouts$1
}, Symbol.toStringTag, { value: "Module" }));
var getWorkout = async (workoutId, currentUserUid) => {
  const usersCollectionRef = collection(FIRESTORE_DB, "users");
  const userDocRef = doc(usersCollectionRef, currentUserUid);
  const userWorkoutsCollectionRef = collection(userDocRef, "workouts");
  const workoutDocRef = doc(userWorkoutsCollectionRef, workoutId);
  const workoutSnap = await getDoc(workoutDocRef);
  if (!workoutSnap.exists()) {
    console.log("No such workout!");
    return null;
  }
  const workoutData = workoutSnap.data();
  const exercises2 = [];
  const exercisesCollectionRef = collection(workoutDocRef, "info");
  const exercisesSnapshot = await getDocs(exercisesCollectionRef);
  for (const exerciseDoc of exercisesSnapshot.docs) {
    const exerciseData = exerciseDoc.data();
    const sets = [];
    const setsCollectionRef = collection(exerciseDoc.ref, "sets");
    const setsSnapshot = await getDocs(setsCollectionRef);
    for (const setDoc2 of setsSnapshot.docs) {
      sets.push({
        ...setDoc2.data(),
        id: setDoc2.id
      });
    }
    exercises2.push({
      ...exerciseData,
      sets,
      id: exerciseDoc.id
    });
  }
  return {
    ...workoutData,
    exercises: exercises2,
    id: workoutSnap.id
  };
};
var ExerciseElement$1 = ({
  set: set2,
  index
}) => {
  return /* @__PURE__ */ jsxs("button", {
    className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
            flex flex-row items-center
            hover:opacity-50 hover:bg-gray-100`,
    onClick: () => {
    },
    children: [/* @__PURE__ */ jsx("p", {
      className: `text-base w-1/3`,
      children: set2.setIndex
    }), /* @__PURE__ */ jsx("p", {
      className: "text-base w-1/3",
      children: set2.reps | 0
    }), /* @__PURE__ */ jsx("p", {
      className: "text-base w-1/3",
      children: set2.weight | 0
    })]
  });
};
async function loader$2({
  params
}) {
  const workoutId = params.workoutId;
  return {
    workoutId
  };
}
var ViewWorkout = ({
  loaderData
}) => {
  const navigate = useNavigate();
  const [workout, setWorkout] = useState(null);
  const {
    t
  } = useTranslation();
  useEffect(() => {
    const fetch2 = async () => {
      var _a;
      const workout2 = await getWorkout(loaderData == null ? void 0 : loaderData.workoutId, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
      setWorkout(workout2);
    };
    fetch2();
  }, []);
  const exerciseItems = workout ? [...workout.exercises] : [];
  return /* @__PURE__ */ jsx("div", {
    className: "w-full h-full font-rubik p-5",
    children: workout ? /* @__PURE__ */ jsxs("div", {
      className: "mt-4 h-[calc(100vh-150px)] overflow-y-scroll",
      children: [/* @__PURE__ */ jsxs("div", {
        className: "flex flex-row gap-x-3",
        children: [/* @__PURE__ */ jsx("button", {
          onClick: () => {
            navigate("/workouts");
          },
          children: /* @__PURE__ */ jsx(FontAwesomeIcon, {
            icon: faArrowLeft,
            className: "w-8 h-8 hover:opacity-60"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "text-3xl font-semibold",
          children: workout.title
        })]
      }), /* @__PURE__ */ jsx("div", {
        className: "w-full h-[2px] bg-gray-100 rounded-full my-2"
      }), /* @__PURE__ */ jsx("div", {
        className: "flex flex-row flex-wrap gap-x-2 gap-y-12 w-full mt-6",
        children: exerciseItems.map((exercise, exerciseIndex) => /* @__PURE__ */ jsxs("div", {
          className: "w-[49%]",
          children: [/* @__PURE__ */ jsxs("div", {
            className: "flex flex-row gap-x-2",
            children: [/* @__PURE__ */ jsx("p", {
              className: "text-xl text-gray-700 font-medium",
              children: exercise.title
            }), /* @__PURE__ */ jsxs("p", {
              className: "text-xl text-red-400 font-medium",
              children: ["(", exerciseIndex + 1, ")"]
            })]
          }), /* @__PURE__ */ jsxs("div", {
            className: "w-full h-full border border-gray-200 rounded-md mb-4",
            children: [/* @__PURE__ */ jsxs("div", {
              className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
              children: [/* @__PURE__ */ jsx("p", {
                className: "w-1/3 text-center text-lg mr-[-24px]",
                children: t("set")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/3 text-center text-lg",
                children: t("reps")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/3 text-center text-lg ml-[-24px]",
                children: t("weight")
              })]
            }), /* @__PURE__ */ jsx(FixedSizeList, {
              height: exercise.sets.length * 40,
              width: "100%",
              itemCount: exercise.sets.length,
              itemSize: 40,
              layout: "vertical",
              children: ({
                index
              }) => {
                const sortedSets = [...exercise.sets].sort((a, b) => a.setIndex - b.setIndex);
                return /* @__PURE__ */ jsx("div", {
                  children: /* @__PURE__ */ jsx(ExerciseElement$1, {
                    set: sortedSets[index],
                    index
                  }, sortedSets[index].setIndex)
                });
              }
            })]
          })]
        }, exercise.id))
      })]
    }) : /* @__PURE__ */ jsx("div", {
      className: "w-[90%] h-[80%] flex items-center justify-center",
      children: /* @__PURE__ */ jsx("p", {
        className: "text-4xl font-medium text-red-400",
        children: t("retreiving-workout")
      })
    })
  });
};
var ViewWorkout$1 = withComponentProps(ViewWorkout);
var route8 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ViewWorkout$1,
  loader: loader$2
}, Symbol.toStringTag, { value: "Module" }));
var SavedWorkouts = () => {
  const [savedWorkouts, setSavedWorkouts] = useState([]);
  const savedWorkoutItems = [...savedWorkouts];
  const navigate = useNavigate();
  const {
    t
  } = useTranslation();
  useEffect(() => {
    const savedWorkoutsLS = localStorage.getItem("saved_workouts");
    const savedWorkouts2 = [];
    if (savedWorkoutsLS) {
      const savedWorkoutsData = JSON.parse(savedWorkoutsLS);
      savedWorkoutsData.forEach((savedWorkout) => {
        savedWorkouts2.push(savedWorkout);
      });
    }
    console.log(savedWorkouts2);
    setSavedWorkouts(savedWorkouts2);
  }, []);
  const SavedWorkoutElement = ({
    workout,
    navigate: navigate2
  }) => {
    const workoutDate = timestampToDate(workout.created).split(" ")[0].slice(0, -1);
    return /* @__PURE__ */ jsxs("button", {
      className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
                flex flex-row items-center
                hover:opacity-50 hover:bg-gray-100`,
      onClick: () => {
        if (workout.title == "Rest~+!_@)#($*&^@&$^*@^$&@*$&#@&#@(&#$@*&($") {
          return;
        }
        navigate2(`/workouts/saved/${workout.id}`);
      },
      children: [/* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: workout.title !== "Rest~+!_@)#($*&^@&$^*@^$&@*$&#@&#@(&#$@*&($" ? workout.title : "Rest Day"
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: workoutDate
      }), /* @__PURE__ */ jsxs("p", {
        className: "text-base w-1/3",
        children: [workout.duration, " ", t("seconds")]
      })]
    });
  };
  const WorkoutsRenderer = ({
    index,
    style
  }) => {
    const sortedWorkoutItems = savedWorkouts.sort((a, b) => {
      if (a.created && b.created) {
        const dateA = new Date(a.created.seconds * 1e3);
        const dateB = new Date(b.created.seconds * 1e3);
        return dateB.getTime() - dateA.getTime();
      }
    });
    const item = sortedWorkoutItems[index] || savedWorkouts[index];
    return /* @__PURE__ */ jsx("div", {
      style,
      children: /* @__PURE__ */ jsx(SavedWorkoutElement, {
        ...item,
        workout: item,
        navigate
      }, item.id)
    });
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("workouts-completed")
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsxs("div", {
      className: "w-full h-1/2 border border-gray-200 rounded-md mt-4",
      children: [/* @__PURE__ */ jsxs("div", {
        className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
        children: [/* @__PURE__ */ jsx("p", {
          className: "w-1/3 text-center text-lg mr-[-24px]",
          children: t("title")
        }), /* @__PURE__ */ jsx("p", {
          className: "w-1/3 text-center text-lg",
          children: t("created-on")
        }), /* @__PURE__ */ jsx("p", {
          className: "w-1/3 text-center text-lg ml-[-24px]",
          children: t("duration")
        })]
      }), /* @__PURE__ */ jsx(FixedSizeList, {
        height: 410,
        width: "100%",
        itemCount: savedWorkoutItems.length,
        itemSize: 40,
        layout: "vertical",
        children: WorkoutsRenderer
      })]
    })]
  });
};
var SavedWorkouts$1 = withComponentProps(SavedWorkouts);
var route9 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: SavedWorkouts$1
}, Symbol.toStringTag, { value: "Module" }));
var getSavedWorkout = async (savedWorkoutId, currentUserUid) => {
  const usersCollectionRef = collection(FIRESTORE_DB, "users");
  const userDocRef = doc(usersCollectionRef, currentUserUid);
  const savedWorkoutsCollectionRef = collection(userDocRef, "saved_workouts");
  const savedWorkoutDocRef = doc(savedWorkoutsCollectionRef, savedWorkoutId);
  const savedWorkoutSnap = await getDoc(savedWorkoutDocRef);
  if (!savedWorkoutSnap.exists()) {
    console.log("No such saved workout!");
    return null;
  }
  const savedWorkoutData = savedWorkoutSnap.data();
  const exercises2 = [];
  const exercisesCollectionRef = collection(savedWorkoutDocRef, "info");
  const exercisesSnapshot = await getDocs(exercisesCollectionRef);
  for (const exerciseDoc of exercisesSnapshot.docs) {
    const exerciseData = exerciseDoc.data();
    const sets = [];
    const setsCollectionRef = collection(exerciseDoc.ref, "sets");
    const setsSnapshot = await getDocs(setsCollectionRef);
    for (const setDoc2 of setsSnapshot.docs) {
      sets.push({
        ...setDoc2.data(),
        id: setDoc2.id
      });
    }
    exercises2.push({
      ...exerciseData,
      sets,
      id: exerciseDoc.id
    });
  }
  return {
    ...savedWorkoutData,
    exercises: exercises2,
    id: savedWorkoutSnap.id
  };
};
var ExerciseElement = ({
  set: set2,
  index
}) => {
  return /* @__PURE__ */ jsxs("button", {
    className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
            flex flex-row items-center
            hover:opacity-50 hover:bg-gray-100`,
    onClick: () => {
    },
    children: [/* @__PURE__ */ jsx("p", {
      className: `text-base w-1/3`,
      children: set2.setIndex
    }), /* @__PURE__ */ jsx("p", {
      className: "text-base w-1/3",
      children: set2.reps | 0
    }), /* @__PURE__ */ jsx("p", {
      className: "text-base w-1/3",
      children: set2.weight | 0
    })]
  });
};
async function loader$1({
  params
}) {
  const savedWorkoutId = params.savedWorkoutId;
  return {
    savedWorkoutId
  };
}
var ViewSavedWorkout = ({
  loaderData
}) => {
  const [savedWorkout, setSavedWorkout] = useState(null);
  const navigate = useNavigate();
  const {
    t
  } = useTranslation();
  useEffect(() => {
    const fetch2 = async () => {
      var _a;
      const savedWorkout2 = await getSavedWorkout(loaderData == null ? void 0 : loaderData.savedWorkoutId, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
      setSavedWorkout(savedWorkout2);
    };
    fetch2();
  }, []);
  const exerciseItems = savedWorkout ? [...savedWorkout.exercises] : [];
  return /* @__PURE__ */ jsx("div", {
    className: "w-full h-full font-rubik p-5",
    children: savedWorkout ? /* @__PURE__ */ jsxs("div", {
      className: "mt-4 h-[calc(100vh-150px)] overflow-y-scroll",
      children: [/* @__PURE__ */ jsxs("div", {
        className: "flex flex-row gap-x-3",
        children: [/* @__PURE__ */ jsx("button", {
          onClick: () => {
            navigate("/workouts/saved");
          },
          children: /* @__PURE__ */ jsx(FontAwesomeIcon, {
            icon: faArrowLeft,
            className: "w-8 h-8 hover:opacity-60"
          })
        }), /* @__PURE__ */ jsx("p", {
          className: "text-3xl font-semibold",
          children: savedWorkout.title
        })]
      }), /* @__PURE__ */ jsx("div", {
        className: "w-full h-[2px] bg-gray-100 rounded-full my-2"
      }), /* @__PURE__ */ jsx("div", {
        className: "flex flex-row flex-wrap gap-x-2 gap-y-12 w-full mt-6",
        children: exerciseItems.map((exercise, exerciseIndex) => /* @__PURE__ */ jsxs("div", {
          className: "w-[49%]",
          children: [/* @__PURE__ */ jsxs("div", {
            className: "flex flex-row gap-x-2",
            children: [/* @__PURE__ */ jsx("p", {
              className: "text-xl text-gray-700 font-medium",
              children: exercise.title
            }), /* @__PURE__ */ jsxs("p", {
              className: "text-xl text-red-400 font-medium",
              children: ["(", exerciseIndex + 1, ")"]
            })]
          }), /* @__PURE__ */ jsxs("div", {
            className: "w-full h-full border border-gray-200 rounded-md mb-4",
            children: [/* @__PURE__ */ jsxs("div", {
              className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
              children: [/* @__PURE__ */ jsx("p", {
                className: "w-1/3 text-center text-lg mr-[-24px]",
                children: t("set")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/3 text-center text-lg",
                children: t("reps")
              }), /* @__PURE__ */ jsx("p", {
                className: "w-1/3 text-center text-lg ml-[-24px]",
                children: t("weight")
              })]
            }), /* @__PURE__ */ jsx(FixedSizeList, {
              height: exercise.sets.length * 40,
              width: "100%",
              itemCount: exercise.sets.length,
              itemSize: 40,
              layout: "vertical",
              children: ({
                index
              }) => {
                const sortedSets = [...exercise.sets].sort((a, b) => a.setIndex - b.setIndex);
                return /* @__PURE__ */ jsx("div", {
                  children: /* @__PURE__ */ jsx(ExerciseElement, {
                    set: sortedSets[index],
                    index
                  }, sortedSets[index].setIndex)
                });
              }
            })]
          })]
        }, exercise.id))
      })]
    }) : /* @__PURE__ */ jsx("div", {
      className: "w-[90%] h-[80%] flex items-center justify-center",
      children: /* @__PURE__ */ jsx("p", {
        className: "text-4xl font-medium text-red-400",
        children: t("retreiving-workout")
      })
    })
  });
};
var ViewSavedWorkout$1 = withComponentProps(ViewSavedWorkout);
var route10 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: ViewSavedWorkout$1,
  loader: loader$1
}, Symbol.toStringTag, { value: "Module" }));
var FoodLog = () => {
  const navigate = useNavigate();
  const {
    t
  } = useTranslation();
  const [foodDays, setFoodDays] = useState([]);
  const [selectedFoodDay, setselectedFoodDayFoodDay] = useState();
  const [initialSelection, setInitialSelection] = useState(true);
  useEffect(() => {
    const foodDaysLS = localStorage.getItem("food_days");
    if (foodDaysLS) {
      setFoodDays(JSON.parse(foodDaysLS));
    }
  }, []);
  useEffect(() => {
    if (initialSelection) {
      setInitialSelection(false);
      return;
    }
    if (selectedFoodDay) {
      const formattedDate = new Date(selectedFoodDay.getTime() - selectedFoodDay.getTimezoneOffset() * 6e4).toISOString().split("T")[0];
      navigate(`/food-log/${formattedDate}`);
    }
  }, [selectedFoodDay]);
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("food-log")
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsx(DayPicker, {
      mode: "single",
      selected: selectedFoodDay,
      onSelect: setselectedFoodDayFoodDay,
      captionLayout: "dropdown",
      modifiers: {
        highlighted: foodDays.map((foodDay) => new Date(foodDay.created))
      },
      modifiersClassNames: {
        highlighted: "bg-blue-500 text-white"
      },
      locale: i18n.language == "en" ? enUS : bg$1
    })]
  });
};
var FoodLog$1 = withComponentProps(FoodLog);
var route11 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: FoodLog$1
}, Symbol.toStringTag, { value: "Module" }));
var getFoodDay = async (foodDate, currentUserUid) => {
  const usersCollectionRef = collection(FIRESTORE_DB, "users");
  const userDocRef = doc(usersCollectionRef, currentUserUid);
  const foodDaysCollectionRef = collection(userDocRef, "food_days");
  const foodDayDocRef = doc(foodDaysCollectionRef, foodDate);
  const foodDaySnapshot = await getDoc(foodDayDocRef);
  if (!foodDaySnapshot.exists()) {
    console.log("Empty!");
    return null;
  }
  const foodDayData = foodDaySnapshot.data();
  const foods = [];
  const foodsCollectionRef = collection(foodDayDocRef, "foods");
  const foodsSnapshot = await getDocs(foodsCollectionRef);
  for (const foodDoc of foodsSnapshot.docs) {
    foods.push({
      ...foodDoc.data(),
      id: foodDoc.id
    });
  }
  return {
    ...foodDayData,
    foods,
    id: foodDaySnapshot.id
  };
};
var FoodElement = ({
  food: food2,
  index
}) => {
  const foodDetails = [{
    label: "Title",
    value: food2.title
  }, {
    label: "Grams",
    value: food2.grams
  }, {
    label: "Calories",
    value: food2.calories
  }, {
    label: "Protein",
    value: food2.protein
  }, {
    label: "Carbs",
    value: food2.carbs
  }, {
    label: "Fat",
    value: food2.fat
  }];
  return /* @__PURE__ */ jsx("button", {
    className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
            flex flex-row items-center
            hover:opacity-50 hover:bg-gray-100`,
    onClick: () => {
    },
    children: foodDetails.map((detail, idx) => /* @__PURE__ */ jsx("p", {
      className: "text-base w-1/6",
      children: detail.value || "-"
    }, idx))
  });
};
async function loader({
  params
}) {
  const foodDate = params.foodDate;
  return {
    foodDate
  };
}
var FoodDay = ({
  loaderData
}) => {
  const navigate = useNavigate();
  const [foodDay, setFoodDay] = useState(null);
  const [date, setDate] = useState("");
  const [loading2, setLoading] = useState(true);
  const [foodDayEmpty, setFoodDayEmpty] = useState(false);
  const {
    t
  } = useTranslation();
  const checkDeleteEmptyFoodDay = async (foodDay2) => {
    var _a;
    console.log(foodDay2);
    if (!foodDay2.calories || !foodDay2.protein || !foodDay2.carbs || !foodDay2.fat) {
      const usersCollectionRef = collection(FIRESTORE_DB, "users");
      const userDocRef = doc(usersCollectionRef, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
      const foodDaysCollectionRef = collection(userDocRef, "food_days");
      const foodDayDocRef = doc(foodDaysCollectionRef, foodDay2.title);
      await deleteDoc(foodDayDocRef);
      console.log("empty - deleted");
    }
    console.log("not empty");
  };
  useEffect(() => {
    const fetch2 = async () => {
      var _a;
      const foodDay2 = await getFoodDay(loaderData.foodDate, (_a = FIREBASE_AUTH.currentUser) == null ? void 0 : _a.uid);
      setFoodDay(foodDay2);
      setDate(loaderData.foodDate);
      setLoading(false);
      if (!(foodDay2 == null ? void 0 : foodDay2.calories) && !(foodDay2 == null ? void 0 : foodDay2.protein) && !(foodDay2 == null ? void 0 : foodDay2.carbs) && !(foodDay2 == null ? void 0 : foodDay2.fat)) {
        setFoodDayEmpty(true);
      }
      if (!foodDay2)
        return;
      checkDeleteEmptyFoodDay(foodDay2);
    };
    fetch2();
  }, [loaderData.foodDate]);
  const foodItems = foodDay ? [...foodDay.foods] : [];
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsxs("div", {
      className: "flex flex-row gap-x-3 mt-5 ",
      children: [/* @__PURE__ */ jsx("button", {
        onClick: () => {
          navigate("/food-log");
        },
        children: /* @__PURE__ */ jsx(FontAwesomeIcon, {
          icon: faArrowLeft,
          className: "w-8 h-8 hover:opacity-60"
        })
      }), /* @__PURE__ */ jsxs("div", {
        className: "flex flex-row gap-x-3 ",
        children: [/* @__PURE__ */ jsx("p", {
          className: "text-3xl font-medium",
          children: t("food-log")
        }), /* @__PURE__ */ jsxs("p", {
          className: "text-3xl text-gray-500",
          children: ["(", foodDay && foodDay.title ? foodDay.title : date, ")"]
        })]
      })]
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2 "
    }), /* @__PURE__ */ jsx("div", {
      className: "mt-2 h-[calc(100vh-150px)] overflow-y-hidden",
      children: loading2 ? /* @__PURE__ */ jsx("div", {
        className: "mt-2",
        children: /* @__PURE__ */ jsx("p", {
          className: "text-xl text-red-500",
          children: t("loading")
        })
      }) : foodDay && !foodDayEmpty ? /* @__PURE__ */ jsx("div", {
        className: "flex flex-row flex-wrap gap-x-2 gap-y-12 w-full mt-2",
        children: /* @__PURE__ */ jsx("div", {
          className: "w-full",
          children: /* @__PURE__ */ jsx("div", {
            className: "w-full flex flex-row justify-between",
            children: /* @__PURE__ */ jsxs("div", {
              className: "w-full h-full border border-gray-200 rounded-md mb-4",
              children: [/* @__PURE__ */ jsxs("div", {
                className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
                children: [/* @__PURE__ */ jsx("p", {
                  className: "w-1/6 text-center text-lg mr-[-10px]",
                  children: t("food-2")
                }), /* @__PURE__ */ jsx("p", {
                  className: "w-1/6 text-center text-lg mr-[-10px]",
                  children: t("grams")
                }), /* @__PURE__ */ jsx("p", {
                  className: "w-1/6 text-center text-lg mr-[-10px]",
                  children: t("calories")
                }), /* @__PURE__ */ jsx("p", {
                  className: "w-1/6 text-center text-lg mr-[-10px]",
                  children: t("protein")
                }), /* @__PURE__ */ jsx("p", {
                  className: "w-1/6 text-center text-lg ml-[-10px]",
                  children: t("carbs")
                }), /* @__PURE__ */ jsx("p", {
                  className: "w-1/6 text-center text-lg mr-2",
                  children: t("fat")
                })]
              }), /* @__PURE__ */ jsx(FixedSizeList, {
                height: foodItems.length * 40,
                width: "100%",
                itemCount: foodItems.length,
                itemSize: 40,
                layout: "vertical",
                children: ({
                  index
                }) => {
                  return /* @__PURE__ */ jsx("div", {
                    children: /* @__PURE__ */ jsx(FoodElement, {
                      food: foodItems[index],
                      index
                    }, foodItems[index].id)
                  });
                }
              }), /* @__PURE__ */ jsx("div", {
                className: "w-full h-full border-[0.5px] border-gray-200",
                children: /* @__PURE__ */ jsx("p", {
                  className: "text-lg font-medium mx-2 my-1",
                  children: t("total")
                })
              }), /* @__PURE__ */ jsx(FoodElement, {
                food: {
                  calories: foodDay.calories,
                  protein: foodDay.protein,
                  carbs: foodDay.carbs,
                  fat: foodDay.fat
                },
                index: 0
              }, 0)]
            })
          })
        })
      }) : /* @__PURE__ */ jsx("div", {
        className: "mt-2",
        children: /* @__PURE__ */ jsx("p", {
          className: "text-xl text-red-500",
          children: t("no-data-available")
        })
      })
    })]
  });
};
var FoodDay$1 = withComponentProps(FoodDay);
var route12 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: FoodDay$1,
  loader
}, Symbol.toStringTag, { value: "Module" }));
var Statistics = () => {
  const [statistics2, setStatistics] = useState([]);
  const statisticItems = [...statistics2];
  const {
    t
  } = useTranslation();
  useEffect(() => {
    const statisticsLS = localStorage.getItem("statistics");
    if (statisticsLS) {
      setStatistics(JSON.parse(statisticsLS));
    }
  }, []);
  const StatisticsElement = ({
    statistic,
    navigate
  }) => {
    return /* @__PURE__ */ jsxs("button", {
      className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
                flex flex-row items-center
                hover:opacity-50 hover:bg-gray-100`,
      onClick: () => {
      },
      children: [/* @__PURE__ */ jsx("p", {
        className: "text-base w-1/2",
        children: statistic.id === "finishedWorkouts" ? t("workouts-completed") : t("total-weight-lifted")
      }), /* @__PURE__ */ jsxs("p", {
        className: "text-base w-1/2",
        children: [statistic.value, " ", statistic.id === "weightLifted" ? "kg" : ""]
      })]
    });
  };
  const StatisticsRenderer = ({
    index,
    style
  }) => {
    const item = statistics2[index];
    return /* @__PURE__ */ jsx("div", {
      style,
      children: /* @__PURE__ */ jsx(StatisticsElement, {
        statistic: item
      }, item.id)
    });
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("statistics")
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsxs("div", {
      className: "w-full h-1/2 border border-gray-200 rounded-md mt-4",
      children: [/* @__PURE__ */ jsxs("div", {
        className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
        children: [/* @__PURE__ */ jsx("p", {
          className: "w-1/2 text-center text-lg mr-[-24px]",
          children: t("statistics")
        }), /* @__PURE__ */ jsx("p", {
          className: "w-1/2 text-center text-lg",
          children: t("values")
        })]
      }), /* @__PURE__ */ jsx(FixedSizeList, {
        height: 410,
        width: "100%",
        itemCount: statisticItems.length,
        itemSize: 40,
        layout: "vertical",
        children: StatisticsRenderer
      })]
    })]
  });
};
var Statistics$1 = withComponentProps(Statistics);
var route13 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Statistics$1
}, Symbol.toStringTag, { value: "Module" }));
var Friends = () => {
  const [friends2, setFriends] = useState([]);
  const friendItems = [...friends2];
  const navigate = useNavigate();
  const {
    t
  } = useTranslation();
  useEffect(() => {
    const friendsLS = localStorage.getItem("friends");
    if (friendsLS) {
      setFriends(JSON.parse(friendsLS));
    }
  }, []);
  const FriendElement = ({
    friend,
    navigate: navigate2
  }) => {
    return /* @__PURE__ */ jsxs("button", {
      className: `w-full h-10 text-gray-600 border-y border-gray-100 px-3 
                flex flex-row items-center
                hover:opacity-50 hover:bg-gray-100`,
      onClick: () => {
      },
      children: [/* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: friend.username
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: "-"
      }), /* @__PURE__ */ jsx("p", {
        className: "text-base w-1/3",
        children: "-"
      })]
    });
  };
  const FriendsRenderer = ({
    index,
    style
  }) => {
    const item = friends2[index];
    return /* @__PURE__ */ jsx("div", {
      style,
      children: /* @__PURE__ */ jsx(FriendElement, {
        ...item,
        friend: item,
        navigate
      }, item.id)
    });
  };
  return /* @__PURE__ */ jsxs("div", {
    className: "w-full h-full font-rubik p-5",
    children: [/* @__PURE__ */ jsx("p", {
      className: "text-3xl text-black mt-5 font-semibold",
      children: t("friends")
    }), /* @__PURE__ */ jsx("div", {
      className: "w-full h-[2px] bg-gray-100 rounded-full mt-2"
    }), /* @__PURE__ */ jsxs("div", {
      className: "w-full h-1/2 border border-gray-200 rounded-md mt-4",
      children: [/* @__PURE__ */ jsxs("div", {
        className: `flex flex-row justify-center gap-x-4 px-1 mt-2 mb-2 font-sans font-semibold`,
        children: [/* @__PURE__ */ jsx("p", {
          className: "w-1/3 text-center text-lg mr-[-24px]",
          children: t("username")
        }), /* @__PURE__ */ jsx("p", {
          className: "w-1/3 text-center text-lg",
          children: t("friend-since")
        }), /* @__PURE__ */ jsx("p", {
          className: "w-1/3 text-center text-lg ml-[-24px]",
          children: t("workouts-completed")
        })]
      }), /* @__PURE__ */ jsx(FixedSizeList, {
        height: 410,
        width: "100%",
        itemCount: friendItems.length,
        itemSize: 40,
        layout: "vertical",
        children: FriendsRenderer
      })]
    })]
  });
};
var Friends$1 = withComponentProps(Friends);
var route14 = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Friends$1
}, Symbol.toStringTag, { value: "Module" }));
var serverManifest = { "entry": { "module": "/assets/entry.client-CE1_f4d0.js", "imports": ["/assets/chunk-SYFQ2XB5-ZRgi9awE.js"], "css": [] }, "routes": { "root": { "id": "root", "parentId": void 0, "path": "", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": true, "module": "/assets/root-Cl-V10dk.js", "imports": ["/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/with-props-DeTQ7wEr.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/index.es-BoLfkVUN.js", "/assets/useTranslation-BDr_u7b1.js", "/assets/GlobalContext-BULYcf-Z.js"], "css": [] }, "routes/Home": { "id": "routes/Home", "parentId": "root", "path": void 0, "index": true, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Home-C54aXIT6.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/GlobalContext-BULYcf-Z.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/useTranslation-BDr_u7b1.js", "/assets/index.esm2017-B54FiO-n.js"], "css": [] }, "routes/Contact": { "id": "routes/Contact", "parentId": "root", "path": "contact", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Contact-DWammarK.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/useTranslation-BDr_u7b1.js", "/assets/index.esm2017-B54FiO-n.js"], "css": [] }, "routes/Account/Account": { "id": "routes/Account/Account", "parentId": "root", "path": "account", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Account-DWtyeHzw.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.es-BoLfkVUN.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/useCheckUsernameNSFW-D2GwpmUs.js", "/assets/GlobalContext-BULYcf-Z.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Account/AccountLogin": { "id": "routes/Account/AccountLogin", "parentId": "root", "path": "login", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/AccountLogin-DZmgu9lk.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/GlobalContext-BULYcf-Z.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Account/AccountRegister": { "id": "routes/Account/AccountRegister", "parentId": "root", "path": "register", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/AccountRegister-DWj2neud.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/useCheckUsernameNSFW-D2GwpmUs.js"], "css": [] }, "routes/Settings": { "id": "routes/Settings", "parentId": "root", "path": "settings", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Settings-Br4kWjL-.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.es-BoLfkVUN.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Workouts/Workouts": { "id": "routes/Workouts/Workouts", "parentId": "root", "path": "workouts", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Workouts-D3Yca9DO.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/useTimestampToDate-D-ZAaOmJ.js", "/assets/index.es-BoLfkVUN.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Workouts/ViewWorkout": { "id": "routes/Workouts/ViewWorkout", "parentId": "root", "path": "workouts/workout/:workoutId", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": true, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/ViewWorkout-D11fEl3O.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/index.es-BoLfkVUN.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/SavedWorkouts/SavedWorkouts": { "id": "routes/SavedWorkouts/SavedWorkouts", "parentId": "root", "path": "workouts/saved/", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/SavedWorkouts-DX3RK4sR.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/useTimestampToDate-D-ZAaOmJ.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/SavedWorkouts/ViewSavedWorkout": { "id": "routes/SavedWorkouts/ViewSavedWorkout", "parentId": "root", "path": "workouts/saved/:savedWorkoutId", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": true, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/ViewSavedWorkout-CrjYX-qF.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.es-BoLfkVUN.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Food/FoodLog": { "id": "routes/Food/FoodLog", "parentId": "root", "path": "food-log", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/FoodLog-YtslTOJD.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/i18next-config-BdAJ4WB8.js", "/assets/useTranslation-BDr_u7b1.js"], "css": ["/assets/FoodLog-B4USAlpw.css"] }, "routes/Food/FoodDay": { "id": "routes/Food/FoodDay", "parentId": "root", "path": "food-log/:foodDate", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": true, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/FoodDay-B0Tb4TMc.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/firebaseConfig-BMTtjb_m.js", "/assets/index.esm2017-B54FiO-n.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/index.es-BoLfkVUN.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Statistics": { "id": "routes/Statistics", "parentId": "root", "path": "statistics", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Statistics-D2sAq7YA.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] }, "routes/Friends": { "id": "routes/Friends", "parentId": "root", "path": "friends", "index": void 0, "caseSensitive": void 0, "hasAction": false, "hasLoader": false, "hasClientAction": false, "hasClientLoader": false, "hasErrorBoundary": false, "module": "/assets/Friends-Bhtq5KEk.js", "imports": ["/assets/with-props-DeTQ7wEr.js", "/assets/chunk-SYFQ2XB5-ZRgi9awE.js", "/assets/index.esm-BsI-V4Ph.js", "/assets/useTranslation-BDr_u7b1.js"], "css": [] } }, "url": "/assets/manifest-8fc0236a.js", "version": "8fc0236a" };
var assetsBuildDirectory = "build/client";
var basename = "/";
var future = { "unstable_optimizeDeps": false };
var isSpaMode = false;
var publicPath = "/";
var entry = { module: entryServer };
var routes = {
  "root": {
    id: "root",
    parentId: void 0,
    path: "",
    index: void 0,
    caseSensitive: void 0,
    module: route0
  },
  "routes/Home": {
    id: "routes/Home",
    parentId: "root",
    path: void 0,
    index: true,
    caseSensitive: void 0,
    module: route1
  },
  "routes/Contact": {
    id: "routes/Contact",
    parentId: "root",
    path: "contact",
    index: void 0,
    caseSensitive: void 0,
    module: route2
  },
  "routes/Account/Account": {
    id: "routes/Account/Account",
    parentId: "root",
    path: "account",
    index: void 0,
    caseSensitive: void 0,
    module: route3
  },
  "routes/Account/AccountLogin": {
    id: "routes/Account/AccountLogin",
    parentId: "root",
    path: "login",
    index: void 0,
    caseSensitive: void 0,
    module: route4
  },
  "routes/Account/AccountRegister": {
    id: "routes/Account/AccountRegister",
    parentId: "root",
    path: "register",
    index: void 0,
    caseSensitive: void 0,
    module: route5
  },
  "routes/Settings": {
    id: "routes/Settings",
    parentId: "root",
    path: "settings",
    index: void 0,
    caseSensitive: void 0,
    module: route6
  },
  "routes/Workouts/Workouts": {
    id: "routes/Workouts/Workouts",
    parentId: "root",
    path: "workouts",
    index: void 0,
    caseSensitive: void 0,
    module: route7
  },
  "routes/Workouts/ViewWorkout": {
    id: "routes/Workouts/ViewWorkout",
    parentId: "root",
    path: "workouts/workout/:workoutId",
    index: void 0,
    caseSensitive: void 0,
    module: route8
  },
  "routes/SavedWorkouts/SavedWorkouts": {
    id: "routes/SavedWorkouts/SavedWorkouts",
    parentId: "root",
    path: "workouts/saved/",
    index: void 0,
    caseSensitive: void 0,
    module: route9
  },
  "routes/SavedWorkouts/ViewSavedWorkout": {
    id: "routes/SavedWorkouts/ViewSavedWorkout",
    parentId: "root",
    path: "workouts/saved/:savedWorkoutId",
    index: void 0,
    caseSensitive: void 0,
    module: route10
  },
  "routes/Food/FoodLog": {
    id: "routes/Food/FoodLog",
    parentId: "root",
    path: "food-log",
    index: void 0,
    caseSensitive: void 0,
    module: route11
  },
  "routes/Food/FoodDay": {
    id: "routes/Food/FoodDay",
    parentId: "root",
    path: "food-log/:foodDate",
    index: void 0,
    caseSensitive: void 0,
    module: route12
  },
  "routes/Statistics": {
    id: "routes/Statistics",
    parentId: "root",
    path: "statistics",
    index: void 0,
    caseSensitive: void 0,
    module: route13
  },
  "routes/Friends": {
    id: "routes/Friends",
    parentId: "root",
    path: "friends",
    index: void 0,
    caseSensitive: void 0,
    module: route14
  }
};
var build = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  assets: serverManifest,
  assetsBuildDirectory,
  basename,
  entry,
  future,
  isSpaMode,
  publicPath,
  routes
}, Symbol.toStringTag, { value: "Module" }));
var _virtual_netlifyServer = createRequestHandler({
  build,
  getLoadContext: async (_req, ctx) => ctx
});

// .netlify/v1/functions/react-router-server.mjs
var config = {
  name: "React Router server handler",
  generator: "@netlify/vite-plugin-react-router@1.0.0",
  path: "/*",
  preferStatic: true
};
export {
  config,
  _virtual_netlifyServer as default
};
